# mctoolsr Analysis

#### 1. Setup ####
library(plyr)
library(dplyr)
library(mctoolsr)
library(RColorBrewer)
library(ggplot2)
library(vegan)
library(Hmisc)
library(ggrepel)
library(tibble)
library(ggh4x)

# Functions
find_hull <- function(df) df[chull(df$Axis01, df$Axis02),]


paste_ranks = function(sm_taxa){
  k = data.frame(k ="k_", sm_taxa['taxonomy1'])
  k2 <- do.call(paste, c(k, sep = ""))
  
  p = data.frame(k ="p_", sm_taxa['taxonomy2'])
  p2 <- do.call(paste, c(p, sep = ""))
  
  c = data.frame(k ="c_", sm_taxa['taxonomy3'])
  c2 <- do.call(paste, c(c, sep = ""))
  
  o = data.frame(k ="o_", sm_taxa['taxonomy4'])
  o2 <- do.call(paste, c(o, sep = ""))
  
  f = data.frame(k ="f_", sm_taxa['taxonomy5'])
  f2 <- do.call(paste, c(f, sep = ""))
  
  g = data.frame(k ="g_", sm_taxa['taxonomy6'])
  g2 <- do.call(paste, c(g, sep = ""))
  
  s = data.frame(k ="s_", sm_taxa['taxonomy7'])
  s2 <- do.call(paste, c(s, sep = ""))
  
  # combine all
  lineage_df = data.frame(k2, p2, c2, o2, f2, g2, s2)
  lineage = do.call(paste, c(lineage_df, sep = ';'))
  return(lineage)
}


# Set working directory
setwd("")

# Input data
tax_table_fp <- "seqtab_wTax_mctoolsr_nomock.txt"
map_fp <- "metadata_16Smtoolsr_nomock_FINAL.txt"
input <- load_taxa_table(tax_table_fp, map_fp)
# 94 samples loaded

# Return number of sequences per sample
sort(colSums(input$data_loaded))

# Rarefying
set.seed(100)
input_rar = single_rarefy(input, 3635)
# 71 samples remaining

# Make sure all values are treated as characters
colSums(input_rar$data_loaded)



#### 2. Guilds ####
# taxa = input_rar$taxonomy_loaded
# OTUs = input_rar$data_loaded
# raw_OTU_table = data.frame(OTUs, taxa)
# taxa[taxa=='NA'] <- ""
# Consensus.lineage = paste_ranks(taxa)
# reformed_OTU_table = data.frame(OTUs, Consensus.lineage) %>%
#   mutate_if(is.integer, as.numeric) %>%
#   mutate(OTU = rownames(.)) %>%
#   dplyr::select(OTU, everything()) %>%
#   left_join(., input_rar$taxonomy_loaded, 
#             by = c("OTU" = "taxonomy7")) %>%
#   dplyr::rename(Kingdom = taxonomy1,
#                 Phylum= taxonomy2,
#                 Class = taxonomy3,
#                 Order = taxonomy4,
#                 Family = taxonomy5,
#                 Genus = taxonomy6) %>%
#   mutate(Taxonomy = Phylum)
# rownames(reformed_OTU_table) <- reformed_OTU_table$OTU
# Guild_OTUs <- Get_16S_Guilds_alt(reformed_OTU_table)
# # Note: This gives an error in R 4.5 but works in R 4.2
# # Cliff will run and share updated input_rar with guild column
# # Export current input_rar to share
# saveRDS(input_rar, "data/input_rar_noguild.rds")
# 

#### 3. Taxa and Ordination ####

# Download taxa with guilds that Cliff made
#setwd("")

input_rar <- readRDS("input_rar_wGuilds.rds")
# Replace old metadata table with new metadata table
meta_updated <- read.delim("metadata_16Smtoolsr_nomock_FINAL.txt")
# Need to make sample IDs the row names first and then remove column
rownames(meta_updated) <- meta_updated$Sample_ID
#meta_updated$Sample_ID <- NULL

# Replace table
input_rar$map_loaded <- meta_updated

unique(input_rar$taxonomy_loaded$taxonomy8)

# Remove samples that were deeper than 45cm

# Identify samples to remove
samples_remove <- c("AM_CH2_45_50", "AM_JA1_42_48", "AM_JA2_40_50",
                    "AM_SA1_42_50", "AM_SA1_50_62", "AM_SA2_50_55",
                    "AM_SA3_40_50", "AM_SD1_42_50", "AM_SD3_40_50",
                    "PP_JA4_40_50")
input_rar$map_loaded$sampleID <- rownames(input_rar$map_loaded)
input_rar <- filter_data(input_rar,
                         filter_cat = "sampleID",
                         filter_vals = samples_remove)
# 62 samples remaining

# Explore guilds further
# Summarize and add columns to map_loaded
tax_sum_guilds <- summarize_taxonomy(input = input_rar, 
                                     level = 8, 
                                     report_higher_tax = F) %>%
  t() %>%
  as.data.frame() %>%
  mutate(SRB_tot = SRB + SRB_syn) %>%
  mutate(CH4gen_tot = CH4_H2 + CH4_me + CH4_mix + CH4_ac) %>%
  mutate(CH4ox_tot = MOB_I + MOB_II + MOB_IIa)
sum(tax_sum_guilds$CH4gen_tot > 0) # 58/71
sum(tax_sum_guilds$CH4ox_tot > 0) # 62/71

input_rar$map_loaded$CH4gen_tot <- tax_sum_guilds$CH4gen_tot
input_rar$map_loaded$CH4ox_tot <- tax_sum_guilds$CH4ox_tot
input_rar$map_loaded$SRB_tot <- tax_sum_guilds$SRB_tot
input_rar$map_loaded$FeRB <- tax_sum_guilds$FeRB
input_rar$map_loaded$FeOB <- tax_sum_guilds$FeOB
input_rar$map_loaded$AOB <- tax_sum_guilds$AOB
input_rar$map_loaded$sampleID <- rownames(input_rar$map_loaded)

# Add individual methanogens
input_rar$map_loaded$CH4_ac  <- tax_sum_guilds$CH4_ac
input_rar$map_loaded$CH4_H2  <- tax_sum_guilds$CH4_H2
input_rar$map_loaded$CH4_me  <- tax_sum_guilds$CH4_me
input_rar$map_loaded$CH4_mix <- tax_sum_guilds$CH4_mix
#View(input_rar$map_loaded)
#View(input_rar$map_loaded)

# Guilds plot
# Guild color palette
library(tidyverse)
library(vegan)
library(mctoolsr)
library(RColorBrewer)
library(car)
Guild_cols <- 
  read.table("Guild_color_palette.txt",
             sep = '\t') %>% # CHANGE MY PATH
  dplyr::select(Guild, G_index, color) %>%
  set_names(c("Guild", "Index", "color")) %>%
  mutate(Index = rev(Index)) %>%
  add_row(Guild = "ANME", Index = 10, color = "#836FFF") %>%
  add_row(Guild = "CH4_me", Index = 16, color = "#FDC086") %>%
  add_row(Guild = "CH4_mix", Index = 17, color = "#FFFF99") %>%
  filter(Guild != "Anamx") %>%
  filter(Guild != "MeOB") %>%
  arrange(Index)
tax_sum_guilds <- summarize_taxonomy(input = input_rar, 
                                     level = 8, 
                                     report_higher_tax = F)


barsG <- plot_taxa_bars(tax_sum_guilds,
                        input_rar$map_loaded,
                        "Sample_ID",
                        num_taxa = 20,
                        data_only = TRUE) %>%
  filter(taxon != "NA") %>%
  droplevels() %>%
  mutate(taxon = factor(taxon,
                        levels = Guild_cols$Guild)) %>%
  mutate(sampleID = group_by) %>%
  left_join(., input_rar$map_loaded, by = c("group_by" = "sampleID"))
tallest_bar <- barsG %>%
  summarise(sum = sum(mean_value))
topgui <- barsG %>%
  group_by(taxon) %>%
  summarise(mean = mean(mean_value)) %>%
  arrange(-mean)
barsG$ThawStage <- factor(barsG$ThawStage, levels = c(
  "Stable", "Early", "Intermediate", "Advanced"
))
gui <- ggplot(barsG, aes(sampleID, mean_value*100, fill = taxon)) +
  geom_bar(stat = "identity", colour = "black", linewidth = 0.1) +
  labs(x = NULL, y = "Relative abundance (%)", fill = "Guild") +
  scale_fill_manual(values = Guild_cols$color) +
  scale_y_continuous(expand = c(0.01, 0.01)) +
  facet_wrap(~ ThawStage, nrow = 1, scales = "free_x") +
  theme_bw() +
  theme(axis.title = element_text(face = "bold", size = 12),
        axis.text = element_text(size = 10),
        axis.line.y = element_blank(),
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        strip.text = element_text(size = 10, face = "bold"),
        strip.background = element_rect(linewidth = 0.2, fill = "white"),
        legend.margin = margin(0, 0, 0, 5, unit = "pt"),
        legend.box.margin = margin(0, 0, 0, -10, unit = "pt"),
        legend.key.size = unit(0.3, "cm"),
        panel.grid.minor = element_blank(),
        panel.grid.major.x = element_blank())
gui

# Now lets zoom into different guilds to investigate further
# From the previous plot, we can see there are some guilds that are quite abundant and worth exploring
# CH4gen, CH4ox, AOB, SRB, FeOB, FeRB
# For each, test effect of depth and Site or ThawStage

# Total methanogens
m <- lm(CH4gen_tot ~ ThawStage * Core_Depth, data = input_rar$map_loaded)
Anova(m, type = "II") # Core Depth***, Thaw Stage ***

# Acetoclastic methanogens
m <- lm(CH4_ac ~ ThawStage * Core_Depth,
           data = input_rar$map_loaded)
Anova(m, type = "II") # Core Depth *

# Hydrogenotrophic methanogens
m <- lm(CH4_H2 ~ ThawStage * Core_Depth,
        data = input_rar$map_loaded)
Anova(m, type = "II") # Thaw Stage ***

# Methyl methanogens
m <- lm(CH4_me ~ ThawStage * Core_Depth,
        data = input_rar$map_loaded)
Anova(m, type = "II") # Core Depth ***

# Mixotrophs
m <- lm(CH4_mix ~ ThawStage * Core_Depth,
        data = input_rar$map_loaded)
Anova(m, type = "II") # Core Depth ***, Thaw stage ***

thaw_cols <- c("darkblue", "skyblue", 
               "goldenrod1", "#B2182B")
input_rar$map_loaded$Core_Depth <- factor(input_rar$map_loaded$Core_Depth, 
                                          levels = c(
                                            "Shallow",
                                            "Intermediate", 
                                            "Deep"
                                          ))
input_rar$map_loaded$ThawStage <- factor(input_rar$map_loaded$ThawStage, 
                                          levels = c(
                                            "Stable",
                                            "Early", 
                                            "Intermediate",
                                            "Advanced"
                                          ))

# Total methanogens
ggplot(input_rar$map_loaded, aes(Core_Depth, CH4gen_tot*100, fill = ThawStage)) +
  geom_boxplot(outliers = FALSE) +
  geom_point(size = 3, pch = 21, position = position_jitterdodge()) +
  labs(x = "Depth",
       y = "Total methanogens (%)") +
  scale_fill_manual(values = thaw_cols) +
  theme_bw(base_size = 16) +
  theme(axis.title = element_text(size = 14),
        axis.text = element_text(size = 12))

# Acetoclastic methanogens
ggplot(input_rar$map_loaded, aes(Core_Depth, CH4_ac*100, fill = ThawStage)) +
  geom_boxplot(outliers = FALSE) +
  geom_point(size = 3, pch = 21, position = position_jitterdodge()) +
  labs(x = "Depth",
       y = "Acetoclastic methanogens (%)") +
  scale_fill_manual(values = thaw_cols) +
  coord_cartesian(ylim = c(0, 0.5)) +
  theme_bw(base_size = 16) +
  theme(axis.title = element_text(size = 14),
        axis.text = element_text(size = 12))

# Hydrogenotrophic methanogens
ggplot(input_rar$map_loaded, aes(Core_Depth, CH4_H2*100, fill = ThawStage)) +
  geom_boxplot(outliers = FALSE) +
  geom_point(size = 3, pch = 21, position = position_jitterdodge()) +
  labs(x = "Depth",
       y = "Hydrogenotrophic methanogens (%)") +
  scale_fill_manual(values = thaw_cols) +
  theme_bw(base_size = 16) +
  theme(axis.title = element_text(size = 14),
        axis.text = element_text(size = 12))

# Methylotrophic methanogens
ggplot(input_rar$map_loaded, aes(Core_Depth, CH4_me*100, fill = ThawStage)) +
  geom_boxplot(outliers = FALSE) +
  geom_point(size = 3, pch = 21, position = position_jitterdodge()) +
  labs(x = "Depth",
       y = "Methyl methanogens (%)") +
  scale_fill_manual(values = thaw_cols) +
  theme_bw(base_size = 16) +
  theme(axis.title = element_text(size = 14),
        axis.text = element_text(size = 12))

# Mixotroph methanogens
ggplot(input_rar$map_loaded, aes(Core_Depth, CH4_mix*100, fill = ThawStage)) +
  geom_boxplot(outliers = FALSE) +
  geom_point(size = 3, pch = 21, position = position_jitterdodge()) +
  labs(x = "Depth",
       y = "Mixotrophs (%)") +
  scale_fill_manual(values = thaw_cols) +
  theme_bw(base_size = 16) +
  theme(axis.title = element_text(size = 14),
        axis.text = element_text(size = 12))

# Methanotrophs
m <- lm(CH4ox_tot ~ ThawStage * Core_Depth, data = input_rar$map_loaded)
Anova(m, type = "II") # NS
library(emmeans)
emm1 <- emmeans(m, ~ ThawStage | Core_Depth)
pairs(emm1, adjust = "tukey")
emmeans(m, ~ ThawStage * Core_Depth)


ggplot(input_rar$map_loaded, aes(Core_Depth, CH4ox_tot*100, fill = ThawStage)) +
  geom_boxplot(outliers = FALSE) +
  geom_point(size = 3, pch = 21, position = position_jitterdodge()) +
  labs(x = "Depth",
       y = "Total methanotrophs (%)") +
  scale_fill_manual(values = thaw_cols) +
  theme_bw(base_size = 16) +
  theme(axis.title = element_text(size = 14),
        axis.text = element_text(size = 12))

# What percent of ch4 fluxes were explained by methanogen increases/
# Let's transform ch4 first
input_rar$map_loaded$sqrt_ch4 <- sign(input_rar$map_loaded$ch4) *
  sqrt(abs(input_rar$map_loaded$ch4))
# Community only
m1 <- lm(sqrt_ch4 ~ CH4gen_tot,
         data = input_rar$map_loaded)
anova(m1)
summary(m1)
summary(m1)$r.squared * 100

# Environmental variables only
m2 <- lm(sqrt_ch4 ~ ThawStage + Core_Depth + SoilTempC +
           SoilMoisture + WaterTableDepth_cm + SeasonalThawDepth_cm,
         data = input_rar$map_loaded)

# Combined model
m3 <- lm(sqrt_ch4 ~ ThawStage + Core_Depth + SoilTempC +
           SoilMoisture + WaterTableDepth_cm + SeasonalThawDepth_cm + CH4gen_tot,
         data = input_rar$map_loaded)

anova(m2, m3)

m4 <- lm(sqrt_ch4 ~ ThawStage + Core_Depth + SoilTempC +
           SoilMoisture + WaterTableDepth_cm + SeasonalThawDepth_cm +
           CH4_H2,
         data = input_rar$map_loaded)

anova(m2, m4)

# Total methanogen abundance and thaw stage
m5 <- lm(sqrt_ch4 ~ CH4gen_tot * ThawStage,
         data = input_rar$map_loaded)
anova(m5)
summary(m5)
summary(m5)$r.squared * 100

ggplot(input_rar$map_loaded,
       aes(CH4gen_tot, sqrt_ch4, color = ThawStage)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  theme_bw()


#### 1. Sequencing summary ####
# Number of samples
n_samples <- ncol(input_rar$data_loaded)

# Number of ASVs
n_asvs <- nrow(input_rar$data_loaded)

# Reads per sample (should all be 3635 if perfectly rarefied)
reads_per_sample <- colSums(input_rar$data_loaded)

mean_reads <- mean(reads_per_sample)
sd_reads <- sd(reads_per_sample)

n_samples
n_asvs
mean_reads
sd_reads

#### 2. Alpha Diversity ####
# Transpose so rows = samples
comm_matrix <- t(input_rar$data_loaded)

# Shannon diversity
shannon <- diversity(comm_matrix, index = "shannon")

# Observed richness
richness <- specnumber(comm_matrix)

# Combine into dataframe
alpha_df <- data.frame(
  Sample_ID = rownames(comm_matrix),
  Shannon = shannon,
  Richness = richness
)

# Join metadata
alpha_df <- left_join(alpha_df,
                      input_rar$map_loaded,
                      by = "Sample_ID")

head(alpha_df)

summary(lm(Shannon ~ ThawStage, data = alpha_df))
anova(lm(Shannon ~ ThawStage, data = alpha_df))

summary(lm(Richness ~ ThawStage, data = alpha_df))
anova(lm(Richness ~ ThawStage, data = alpha_df))

#### 3. Beta Diversity ####

# Bray-Curtis dissimilarity
dm <- vegdist(comm_matrix, method = "bray")

# PERMANOVA
ado <- adonis2(dm ~ ThawStage * Core_Depth,
               data = input_rar$map_loaded)

ado

# Test dispersion
anova(betadisper(dm, input_rar$map_loaded$ThawStage))


# Test if site along is significant
adonis2(dm ~ Site * Core_Depth, data = input_rar$map_loaded)

adonis2(
  dm ~ ThawStage + Core_Depth,
  data = input_rar$map_loaded,
  permutations = 999,
  by = "terms"
)

# Reviewer 2 asked for more conservative permutation design:
# Let's do plot-level PERMANOVA
comm_rel <- decostand(comm_matrix, method = "total")
head(comm_rel[, 1:5])

plot_id <- input_rar$map_loaded$PlotID_unique

comm_plot <- rowsum(comm_rel, group = plot_id) /
  as.vector(table(plot_id))

dim(comm_plot)

# Plot level PERMANOVA
plot_meta <- input_rar$map_loaded %>%
  dplyr::select(PlotID_unique, ThawStage) %>%
  dplyr::distinct()

table(plot_meta$ThawStage)

dm_plot <- vegdist(comm_plot, method = "bray")

adonis_plot <- adonis2(
  dm_plot ~ ThawStage,
  data = plot_meta,
  permutations = 9999
)

adonis_plot

# Test for thaw stage x core depth interaction
adonis_depth <- adonis2(
  dm ~ ThawStage * Core_Depth,
  data = input_rar$map_loaded,
  by = "terms",
  permutations = 9999,
  strata = input_rar$map_loaded$PlotID_unique
)

adonis_depth


#### 4. NMDS Ordination & Environmental fitting ####
comm_matrix <- t(input_rar$data_loaded)
dm <- vegdist(comm_matrix, method = "bray")
set.seed(100)
nmds <- metaMDS(dm, trymax = 200)
nmds$stress

# Environmental variables
env_vars <- input_rar$map_loaded %>%
  dplyr::select(SoilTempC,
                #SoilMoisture,
                WaterTableDepth_cm,
                SeasonalThawDepth_cm,
                mean_13C,
                co2,
                ch4)

ef <- envfit(nmds, env_vars, permutations = 999, na.rm = TRUE)
ef

#### 5. Distance-based RDA (Environmental Drivers) ####
library(tidyr)
env_nona <- env_vars %>% drop_na()
comm_nona <- comm_matrix[rownames(comm_matrix) %in% rownames(env_nona), ]

mod0 <- rda(comm_nona ~ 1, env_nona)
mod1 <- rda(comm_nona ~ ., env_nona)

mod_selected <- ordistep(mod0, scope = formula(mod1))
mod_selected
anova(mod_selected)
summary(mod_selected)

#### 6. Taxonomic shifts ####
tax_sum_phyla <- summarize_taxonomy(input = input_rar,
                                    level = 2,
                                    report_higher_tax = F,
                                    relative = T)

# Create long format table
tax_long <- tax_sum_phyla %>%
  as.data.frame() %>%
  rownames_to_column(var = "Phylum") %>%
  pivot_longer(
    cols = -Phylum,
    names_to = "Sample_ID",
    values_to = "RelAbundance"
  )

tax_long <- left_join(tax_long,
                      input_rar$map_loaded,
                      by = "Sample_ID")
head(tax_long)

## Let's see what Bacterodoita taxa are increasing with thaw
# Let's check at the family level first

# Pull out bacterodoita phyla
input_bact <- input_rar
input_bact$taxonomy_loaded <- input_rar$taxonomy_loaded %>% filter(taxonomy2 == "Bacteroidota")
tax_sum_family <- summarize_taxonomy(input = input_bact,
                                     level = 5,
                                     report_higher_tax = F,
                                     relative = T)
tax_long2 %>% group_by(Family) %>% summarise(p = summary(lm(RelAbundance ~ ThawStage))$coefficients[2,4], .groups = "drop") %>% filter(p < 0.05) %>% arrange(p)

bact_families <- unique(input_rar$taxonomy_loaded$taxonomy5[input_rar$taxonomy_loaded$taxonomy2 == "Bacteroidota"])

# Now let's focus on the family level
tax_bact <- tax_long2 %>% filter(Family %in% bact_families)

# Group by thaw stage and calculate significance of change
tax_bact %>% group_by(Family) %>% filter(n_distinct(ThawStage) >= 2) %>% do(broom::tidy(anova(lm(RelAbundance ~ ThawStage, data = .)))) %>% filter(term == "ThawStage", p.value < 0.05) %>% arrange(p.value)

# Calculate mean abundance in each thaw stage to see trend
tax_bact %>% filter(Family %in% c("Ignavibacteriales_unclassified","Chitinophagales_unclassified","Sphingobacteriaceae","uncultured","SR-FBR-L83")) %>% group_by(Family, ThawStage) %>% summarise(mean = mean(RelAbundance), .groups = "drop")
# SR-FBR-L83 increases with thaw **
# Uncultured decreases
# Chitinophagales_unclassified change isn't meaningful
# Sphingobacteriaceae doesn't change
# Ignavibacteriales_unclassified has a blip in early

#SR-FBR-L83
sr <- input_bact$taxonomy_loaded[input_bact$taxonomy_loaded$taxonomy5 == "SR-FBR-L83",]


# See top 10 phyla
top_phyla <- tax_long %>%
  dplyr::group_by(Phylum) %>%
  dplyr::summarise(mean_abund = mean(RelAbundance, na.rm = TRUE),
            .groups = "drop") %>%
  dplyr::arrange(desc(mean_abund)) %>%
  dplyr::slice(1:10)

print(top_phyla)

# Test top 6 phyla
top6 <- top_phyla$Phylum[1:6]

library(broom)
phylum_tests <- tax_long %>%
  dplyr::filter(Phylum %in% top6) %>%
  dplyr::group_by(Phylum) %>%
  do(
    tidy(anova(lm(RelAbundance ~ ThawStage, data = .)))
  )

phylum_tests

# See what direction these groups are shifting along the thaw gradient
mean_by_stage <- tax_long %>%
  dplyr::filter(Phylum %in% top6) %>%
  dplyr::group_by(Phylum, ThawStage) %>%
  dplyr::summarise(mean_abund = mean(RelAbundance),
            .groups = "drop")

print(mean_by_stage, n = 24)
unique(tax_long$Phylum)

# Check the light purple bar shift
bact_df <- tax_long %>%
  dplyr::filter(Phylum == "Bacteroidota") %>%
  dplyr::group_by(ThawStage) %>%
  dplyr::summarise(mean_abund = mean(RelAbundance),
            sd_abund = sd(RelAbundance),
            .groups = "drop")

bact_df

anova(lm(RelAbundance ~ ThawStage,
         data = tax_long %>% filter(Phylum == "Bacteroidota")))

# Chloroflexi
chloro_df <- tax_long %>%
  dplyr::filter(Phylum == "Chloroflexi") %>%
  dplyr::group_by(ThawStage) %>%
  dplyr::summarise(mean_abund = mean(RelAbundance),
                   sd_abund = sd(RelAbundance),
                   .groups = "drop")

chloro_df

anova(lm(RelAbundance ~ ThawStage,
         data = tax_long %>% filter(Phylum == "Chloroflexi")))



#### 7. Archaeael & Methanogen abundance ####
# Extract archaeal phyla
archaea_phyla <- c("Euryarchaeota", 
                   "Halobacterota", 
                   "Thermoplasmatota", 
                   "Crenarchaeota",
                   "Asgardarchaeota",
                   "Nanoarchaeota",
                   "Micrarchaeota")

archaea_df <- tax_long %>%
  dplyr::filter(Phylum %in% archaea_phyla) %>%
  dplyr::group_by(Sample_ID, ThawStage) %>%
  dplyr::summarise(total_archaea = sum(RelAbundance),
            .groups = "drop")

head(archaea_df)

anova(lm(total_archaea ~ ThawStage, data = archaea_df))
summary(lm(total_archaea ~ ThawStage, data = archaea_df))

# Isolate methanogens (Euryarchaeota)
eury_df <- tax_long %>%
  dplyr::filter(Phylum == "Euryarchaeota") %>%
  dplyr::group_by(Sample_ID, ThawStage) %>%
  dplyr::summarise(mean_abund = mean(RelAbundance),
            .groups = "drop")

anova(lm(mean_abund ~ ThawStage, data = eury_df))
summary(lm(mean_abund ~ ThawStage, data = eury_df))

#### 8. Does methanogen abundance correlate with CH4 flux? ####

# Let's only look at shallow depth first, because we took surface fluxes
eury_shallow <- tax_long %>%
  dplyr::filter(Phylum == "Euryarchaeota",
         Core_Depth == "Shallow") %>%
  dplyr::select(Sample_ID, Site, PlotID, ThawStage, RelAbundance)

flux <- read.csv("Environmental_Data/Data/July2022BetaFluxes.csv")

flux_plot <- flux %>%
  dplyr::group_by(Site, PlotID) %>%
  dplyr::summarise(ch4_flux = mean(ch4_flux_umol_m2_min_dark, na.rm = TRUE),
            .groups = "drop")

eury_shallow_flux <- eury_shallow %>%
  left_join(flux_plot, by = c("Site", "PlotID")) %>%
  dplyr::group_by(Site, PlotID) 

cor.test(eury_shallow_flux$RelAbundance,
         eury_shallow_flux$ch4_flux,
         method = "spearman")


# Okay now let's average the methanogen abundance per plot across all depths
eury_plot_avg <- tax_long %>%
  dplyr::filter(Phylum == "Euryarchaeota") %>%
  dplyr::group_by(Site, PlotID) %>%
  dplyr::summarise(mean_abund = mean(RelAbundance),
            .groups = "drop")

eury_plot_flux <- eury_plot_avg %>%
  left_join(flux_plot, by = c("Site", "PlotID"))

cor.test(eury_plot_flux$mean_abund,
         eury_plot_flux$ch4_flux,
         method = "spearman")





#### 9. Faceted bar plot####

# Barplot by sampleID with facet by variable
tax_sum_phyla_16S <- summarize_taxonomy(input = input_rar, 
                                        level = 2, 
                                        report_higher_tax = F)
bars_phyla_16S <- plot_taxa_bars(tax_sum_phyla_16S,
                                 input_rar$map_loaded,
                                 "Sample_ID",
                                 num_taxa = 12,
                                 data_only = TRUE) %>%
  mutate(taxon = fct_rev(taxon)) %>%
  left_join(., input_rar$map_loaded, by = c("group_by" = "Sample_ID"))
top_phyla_16S <- bars_phyla_16S %>%
  dplyr::group_by(taxon) %>%
  dplyr::summarise(mean = mean(mean_value)) %>%
  filter(taxon != "Other") %>%
  arrange(-mean) %>%
  mutate(taxon = as.character(taxon))
bars_phyla_16S <- bars_phyla_16S %>%
  mutate(taxon = factor(taxon,
                        levels = c("Other", rev(top_phyla_16S$taxon)))) %>%
  mutate(Site = factor(Site,
                       levels = c("PP", "AM"))) %>%
  mutate(ThawStage = factor(ThawStage,
                            levels = c("Stable", "Early", "Intermediate",
                                       "Advanced")))
# New phylum names since we start the analysis, so need to update the names
bars_phyla_16S <- bars_phyla_16S %>%
  mutate(taxon = recode(taxon,
                        "Proteobacteria" = "Pseudomonadota",
                        "Firmicutes" = "Bacillota"))

ggplot(bars_phyla_16S, aes(group_by, mean_value, fill = taxon)) +
  geom_bar(stat = "identity", colour = NA, linewidth = 0.25) +
  labs(x = "Sample", y = "Relative abundance", fill = "Phylum") +
  scale_fill_manual(values = c("grey90", brewer.pal(12, "Paired")[12:1])) +
  scale_y_continuous(expand = c(0.01, 0.01)) + 
  facet_nested(~ Site + ThawStage, space = "free", scales = "free_x") +
  theme_classic() +
  theme(axis.title.y = element_text(face = "bold", size = 12),
        axis.title.x = element_blank(),
        axis.text.y = element_text(size = 10),
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.line.x = element_blank(),
        axis.line.y = element_blank(),
        strip.text = element_text(size = 10),
        strip.background = element_rect(linewidth = 0.2),
        strip.text.x = element_text(face = "bold"),
        legend.position = "right",
        legend.margin = margin(0, 0, 0, 0, unit = "pt"),
        legend.box.margin = margin(0, 0, 0, 0, unit = "pt"),
        legend.key.size = unit(0.5, "cm"))

ggsave("16S_phyla_updated.jpg", width = 9, height = 5)

#### 10. Ordination plot ####
set.seed(100)
dm = calc_dm(input_rar$data_loaded)
nmds <- metaMDS(dm, trymax = 200)
stressplot(nmds)
nmds$stress
# Make new dataframe with just continuous env. variables
names(input_rar$map_loaded)
d_env <- input_rar$map_loaded %>%
  dplyr::select(SoilTempC,
                # SoilMoisture, #Not significant
                WaterTableDepth_cm,
                SeasonalThawDepth_cm,
                mean_13C,
                # co2, # Not significant
                ch4)
set.seed(100)
ef <- envfit(nmds, d_env, permutations = 999, na.rm = TRUE)
ef
ordiplot(nmds)
plot(ef, cex = 0.5, p.max = 0.05)
multiplier <- ordiArrowMul(ef)
multiplier
vec.df <- as.data.frame(ef$vectors$arrows * sqrt(ef$vectors$r)) %>%
  mutate(
    NMDS1 = NMDS1 * multiplier,
    NMDS2 = NMDS2 * multiplier
  ) %>%
  mutate(variables = rownames(.)) %>%
  # filter(ef$vectors$pvals <= 0.05) %>%
  mutate(
    shortnames = c(
      "bold(    Soil~T)",
      #  "bold(Soil~M)", # Not significant
      "bold(Water~Table)",
      "bold(AL)",
      "bold(delta^{13}*C~CH[4])",
      #    "bold(CO[2])", # Not significant
      "bold(CH[4])"
    ),
    label_x = case_when(
      variables == "SoilTempC" ~ NMDS1 + 0.06,  # right
      variables == "ch4" ~ NMDS1 - 0.08,        # left
      variables == "mean_13C" ~ NMDS1 + 0.02, 
      TRUE ~ NMDS1
    ),
    label_y = case_when(
      variables == "SoilTempC" ~ NMDS2 - 0.07,  # down
      variables == "ch4" ~ NMDS2 - 0.09,        # down
      variables == "mean_13C" ~ NMDS1 + 0.08, 
      TRUE ~ NMDS2
    )
  )

input_rar$map_loaded$Axis01 <- vegan::scores(nmds)[,1]
input_rar$map_loaded$Axis02 <- vegan::scores(nmds)[,2] 

# Factor the thaw stages and core depths
input_rar$map_loaded$ThawStage <- factor(
  input_rar$map_loaded$ThawStage,
  levels = c("Stable", "Early", "Intermediate", "Advanced")
)

input_rar$map_loaded$Core_Depth <- factor(
  input_rar$map_loaded$Core_Depth,
  levels = c("Shallow", "Intermediate", "Deep")
)

# Site + Core Depth + Thaw Stage
micro.hulls <- ddply(input_rar$map_loaded, c("Site"), find_hull)
ggplot(input_rar$map_loaded, aes(Axis01, Axis02)) +
  geom_polygon(
    data = micro.hulls,
    aes(fill = Site),
    colour = NA,
    alpha = 0.1,
    show.legend = FALSE
  ) +
  geom_point(
    aes(colour = ThawStage, shape = Core_Depth),
    size = 4
  ) +
  geom_segment(
    data = vec.df,
    aes(x = 0, xend = NMDS1, y = 0, yend = NMDS2),
    arrow = arrow(length = unit(0.35, "cm")),
    colour = "black", alpha = 0.6,
    inherit.aes = FALSE
  ) +
  geom_text_repel(
    data = vec.df,
    aes(x = label_x, y = label_y, label = shortnames),
    size = 6, parse = TRUE
  ) +
  geom_text(
    aes(x = -1, y = 0.7, label = "stress = 0.10"),
    size = 6
  ) +
  scale_colour_manual(
    values = c(
      "Stable" = "darkblue",        # blue
      "Early" = "skyblue",         # light blue
      "Intermediate" = "goldenrod1",  # orange
      "Advanced" = "#B2182B"       # reddish orange
    )
  ) +
  scale_shape_manual(values = c(15, 16, 17)) +
  labs(
    x = "NMDS1",
    y = "NMDS2",
    colour = "Thaw Stage",
    shape = "Core Depth"
  ) +
  theme_bw(base_size = 16) +
  theme(legend.position = "right",
        axis.title = element_text(size = 14), 
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        panel.grid = element_blank())

ggsave("Ordination_Plot_16S.jpg", width = 10, height = 6)


table(input_rar$map_loaded$ThawStage,
      input_rar$map_loaded$Core_Depth)
