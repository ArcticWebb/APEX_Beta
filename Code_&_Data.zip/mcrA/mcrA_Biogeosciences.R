# mctoolsr Analysis

#### Setup ####
library(dplyr)
library(plyr)
library(mctoolsr)
library(RColorBrewer)
library(ggplot2)
library(vegan)
library(Hmisc)
library(ggrepel)
library(tibble)
library(Biostrings)

# Functions
`%notin%` <- Negate(`%in%`)
find_hull <- function(df) df[chull(df$Axis01, df$Axis02),]

paste_ranks = function(sm_taxa){
  k = data.frame(k ="k_", sm_taxa['taxonomy1'])
  k2 <- do.call(paste, c(k, sep = ""))
  
  p = data.frame(k ="p_", sm_taxa['taxonomy2'])
  p2 <- do.call(paste, c(p, sep = ""))
  
  c = data.frame(k ="c_", sm_taxa['taxonomy3'])
  c2 <- do.call(paste, c(c, sep = ""))
  
  o = data.frame(k ="o_", sm_taxa['taxonomy4'])
  o2 <- do.call(paste, c(o, sep = ""))
  
  f = data.frame(k ="f_", sm_taxa['taxonomy5'])
  f2 <- do.call(paste, c(f, sep = ""))
  
  g = data.frame(k ="g_", sm_taxa['taxonomy6'])
  g2 <- do.call(paste, c(g, sep = ""))
  
  s = data.frame(k ="s_", sm_taxa['taxonomy7'])
  s2 <- do.call(paste, c(s, sep = ""))
  
  # combine all
  lineage_df = data.frame(k2, p2, c2, o2, f2, g2, s2)
  lineage = do.call(paste, c(lineage_df, sep = ';'))
  return(lineage)
}


# Set working directory
setwd("")

# Input data
# Replace with the actual path to your file
feature_table <- read.delim("feature-table.txt", 
                            header = TRUE,        
                            stringsAsFactors = FALSE,
                            check.names = FALSE   # keep sample names exactly as they are
)

# View first few rows
head(feature_table)

# Import mctoolsr object
tax_table_fp <- "./data/seqtab_woTax_mctoolsr_mcrA.txt"
map_fp <- "./data/metadata_16Smtoolsr_nomock_FINAL.txt"
input <- load_taxa_table(tax_table_fp, map_fp)
# 94 samples loaded


# Return number of sequences per sample
sort(colSums(input$data_loaded))

# Rarefying
rarecurve(t(input$data_loaded), step = 500, label = F)
abline(v = 2872, col = "red")
abline(v = 4498, col = "red")
set.seed(100)
input_rar = single_rarefy(input, 4498)
# 88 samples remaining

# Make sure all values are 4498
colSums(input_rar$data_loaded)
#View(input_rar$data_loaded)


### Remove deeper samples 
# Identify super deep samples
samples_remove <- c("AM_CH2_45_50", "AM_JA1_42_48", "AM_JA2_40_50",
                    "AM_SA1_42_50", "AM_SA1_50_62", "AM_SA2_50_55",
                    "AM_SA3_40_50", "AM_SD1_42_50", "AM_SD3_40_50",
                    "PP_JA4_40_50")
input_rar$map_loaded$sampleID <- rownames(input_rar$map_loaded)
input_rar <- filter_data(input_rar,
                         filter_cat = "sampleID",
                         filter_vals = samples_remove)
# 80 samples remaining
head(input_rar$taxonomy_loaded)
nrow(input_rar$taxonomy_loaded) # 1481

#### GTDB Taxonomy data ####
library(readr)
mcrA_tax_gtdb <- read_tsv(
  "./data/mcrA_GTDB_taxonomy.tsv",
  col_names = FALSE
)
# Update column names
colnames(mcrA_tax_gtdb) <- c(
  "genome_id",
  "asv_id",
  "protein_id",
  "pident",
  "aln_length",
  "evalue",
  "bitscore",
  "gtdb_taxonomy"
)

# 10159 rows because there is more than one hit per ASV
# Let's select the top hit 
mcrA_top <- mcrA_tax_gtdb %>%
  group_by(asv_id) %>%
  arrange(dplyr::desc(bitscore), evalue, dplyr::desc(pident)) %>%
  dplyr::slice(1) %>%
  ungroup()
unique(mcrA_tax_gtdb$gtdb_taxonomy)

# Calculate query lengths
library(Biostrings)
getwd()
seqs <- readAAStringSet("dna-sequences.fasta")   
query_lengths <- width(seqs)

query_df <- data.frame(
  asv_id = names(seqs),
  query_length = query_lengths
)

# Remove low pident and alignment legnths
mcrA_filtered <- mcrA_top %>%
  filter(
    pident >= 90,
    aln_length >= 60
  )

# Create clean database
# Remove unnecessary columns
mcrA_top <- mcrA_filtered %>%
  dplyr::select(-genome_id, -protein_id,
         -aln_length, -evalue, -bitscore)

# Split up taxonomy
library(tidyr)
mcrA_tax_split <- mcrA_top %>%
  separate(
    gtdb_taxonomy,
    into = c(
      "domain",
      "phylum",
      "class",
      "order",
      "family",
      "genus",
      "species"
    ),
    sep = ";",
    fill = "right"
  )
mcrA_tax_split <- mcrA_tax_split %>%
  dplyr::mutate(across(
    domain:species,
    ~ gsub("^[^A-Za-z]*[a-z]__+", "", as.character(.x))
  ))

table(mcrA_tax_split$phylum)
table(mcrA_tax_split$class)
table(mcrA_tax_split$order)
table(mcrA_tax_split$family)
table(mcrA_tax_split$genus)
table(mcrA_tax_split$species)

head(mcrA_tax_split)
head(input_rar$taxonomy_loaded)

# convert mcrA data to taxonomy_loaded format
new_taxonomy <- mcrA_tax_split %>%
  dplyr::select(asv_id, domain, phylum, class, order, family, genus) %>%
  dplyr::rename(
    taxonomy1 = domain,
    taxonomy2 = phylum,
    taxonomy3 = class,
    taxonomy4 = order,
    taxonomy5 = family,
    taxonomy6 = genus
  )

# Add taxonomy7 as ASV ID
new_taxonomy$taxonomy7 <- new_taxonomy$asv_id

# Convert to data.frame and set rownames
new_taxonomy <- as.data.frame(new_taxonomy)
rownames(new_taxonomy) <- new_taxonomy$asv_id

# Remove asv_id column (since old table does not contain it)
new_taxonomy$asv_id <- NULL

# Replace old taxonomy table
input_rar$taxonomy_loaded <- new_taxonomy

#### 1. mcrA Alpha diversity ####
comm_matrix <- t(input_rar$data_loaded)

shannon_mcrA <- diversity(comm_matrix, index = "shannon")
richness_mcrA <- specnumber(comm_matrix)

alpha_mcrA <- data.frame(
  sampleID = rownames(comm_matrix),
  Shannon = shannon_mcrA,
  Richness = richness_mcrA
) %>%
  dplyr::left_join(input_rar$map_loaded, by = "sampleID")

# Test diversity along thaw gradient
anova(lm(Shannon ~ ThawStage, data = alpha_mcrA))
anova(lm(Richness ~ ThawStage, data = alpha_mcrA))
# Test diversity along depth gradient
anova(lm(Shannon ~ ThawStage * Core_Depth, data = alpha_mcrA))
anova(lm(Richness ~ ThawStage * Core_Depth, data = alpha_mcrA))


alpha_mcrA %>%
  dplyr::group_by(ThawStage) %>%
  dplyr::summarise(
    mean_shannon = mean(Shannon),
    mean_richness = mean(Richness),
    .groups = "drop"
  )
# Looks like diversity decreases from stable to intermidate but then increases
# dramatically in advanced

alpha_mcrA %>%
  dplyr::group_by(ThawStage, Core_Depth) %>%
  dplyr::summarise(
    mean_shannon = mean(Shannon),
    mean_richness = mean(Richness),
    .groups = "drop"
  )

#### 2. mcrA community composition ####
# Bray-Curtis distance
comm_matrix <- t(input_rar$data_loaded)

dm_mcrA <- vegdist(comm_matrix, method = "bray")

# PERMANOVA
adonis_mcrA <- adonis2(dm_mcrA ~ ThawStage * Core_Depth,
                       data = input_rar$map_loaded)

adonis_mcrA
adonis2(dm_mcrA ~ ThawStage * Core_Depth,
        data = input_rar$map_loaded,
        by = "terms")


# Test homogeneity of dispersion
anova(betadisper(dm_mcrA, input_rar$map_loaded$ThawStage))

#### 3. mcrA taxonomic composition ####
# Keep only taxonomy rows that are present in data_loaded
input_rar$taxonomy_loaded <- input_rar$taxonomy_loaded[
  rownames(input_rar$taxonomy_loaded) %in% rownames(input_rar$data_loaded),
]

# Confirm dimensions now match
dim(input_rar$data_loaded)
dim(input_rar$taxonomy_loaded)

# Confirm rownames match exactly and in same order
input_rar$taxonomy_loaded <- input_rar$taxonomy_loaded[
  rownames(input_rar$data_loaded),
]

all(rownames(input_rar$data_loaded) == rownames(input_rar$taxonomy_loaded))

# ASVs present in data but missing from taxonomy
setdiff(rownames(input_rar$data_loaded),
        rownames(input_rar$taxonomy_loaded))

# Remove ASVs without taxonomy
input_rar$data_loaded <- input_rar$data_loaded[
  rownames(input_rar$data_loaded) %in% rownames(input_rar$taxonomy_loaded),
]

# Reorder taxonomy to match data exactly
input_rar$taxonomy_loaded <- input_rar$taxonomy_loaded[
  rownames(input_rar$data_loaded),
]

# Confirm perfect alignment
dim(input_rar$data_loaded)
dim(input_rar$taxonomy_loaded)

all(rownames(input_rar$data_loaded) == rownames(input_rar$taxonomy_loaded))




unique(input_rar$taxonomy_loaded$taxonomy3)

# Summarize mcrA at genus level
tax_sum_genus_mcrA <- summarize_taxonomy(input = input_rar,
                                         level = 6,
                                         report_higher_tax = FALSE,
                                         relative = TRUE)

head(tax_sum_genus_mcrA[,1:5])

dim(input_rar$data_loaded)
dim(input_rar$taxonomy_loaded)
all(rownames(input_rar$data_loaded) == rownames(input_rar$taxonomy_loaded))

# Identify dominant mcrA genera
# Convert to long format
tax_long_mcrA <- tax_sum_genus_mcrA %>%
  as.data.frame() %>%
  tibble::rownames_to_column("Genus") %>%
  tidyr::pivot_longer(
    cols = -Genus,
    names_to = "Sample_ID",
    values_to = "RelAbundance"
  )

# Calculate mean abundance per genus
top_genera_mcrA <- tax_long_mcrA %>%
  dplyr::group_by(Genus) %>%
  dplyr::summarise(mean_abund = mean(RelAbundance)) %>%
  dplyr::arrange(desc(mean_abund)) %>%
  dplyr::slice(1:10)

print(top_genera_mcrA)

# Test how dominant genera shift across thaw
top4 <- c("Methanobacterium_B",
          "Methanosarcina",
          "Methanoregula",
          "Methanothrix")

genus_stage_means <- tax_long_mcrA %>%
  dplyr::filter(Genus %in% top4) %>%
  dplyr::left_join(input_rar$map_loaded, by = c("Sample_ID" = "sampleID")) %>%
  dplyr::group_by(Genus, ThawStage) %>%
  dplyr::summarise(mean_abund = mean(RelAbundance),
                   .groups = "drop")

print(genus_stage_means)

genus_tests <- tax_long_mcrA %>%
  dplyr::filter(Genus %in% top4) %>%
  dplyr::left_join(input_rar$map_loaded, by = c("Sample_ID" = "sampleID")) %>%
  dplyr::group_by(Genus) %>%
  dplyr::do(
    broom::tidy(anova(lm(RelAbundance ~ ThawStage, data = .)))
  )

print(genus_tests)

# Look at changes along core depth
genus_stage_depth_means <- tax_long_mcrA %>%
  dplyr::filter(Genus %in% top4) %>%
  dplyr::left_join(input_rar$map_loaded,
                   by = c("Sample_ID" = "sampleID")) %>%
  dplyr::group_by(Genus, ThawStage, Core_Depth) %>%
  dplyr::summarise(mean_abund = mean(RelAbundance),
                   .groups = "drop")

print(genus_stage_depth_means, n =48)

genus_tests_depth <- tax_long_mcrA %>%
  dplyr::filter(Genus %in% top4) %>%
  dplyr::left_join(input_rar$map_loaded, by = c("Sample_ID" = "sampleID")) %>%
  dplyr::group_by(Genus) %>%
  dplyr::do(
    broom::tidy(anova(lm(RelAbundance ~ ThawStage * Core_Depth, data = .)))
  )

print(genus_tests_depth)


#### 4. NMDS Ordination ####
# Ordination with environmental vectors and hulls
set.seed(100)
dm = calc_dm(input_rar$data_loaded)
nmds <- metaMDS(dm, trymax = 200)
stressplot(nmds)
nmds$stress

# Environmental variables
env_vars <- input_rar$map_loaded %>%
  dplyr::select(SoilTempC,
                SoilMoisture,
                WaterTableDepth_cm,
                SeasonalThawDepth_cm,
                mean_13C,
                co2,
                ch4)

ef <- envfit(nmds, env_vars, permutations = 999, na.rm = TRUE)
ef

#### 5. Distance-based RDA (Environmental Drivers) ####
env_nona <- env_vars %>% drop_na()
comm_nona <- comm_matrix[rownames(comm_matrix) %in% rownames(env_nona), ]

mod0 <- rda(comm_nona ~ 1, env_nona)
mod1 <- rda(comm_nona ~ ., env_nona)

mod_selected <- ordistep(mod0, scope = formula(mod1))
mod_selected
anova(mod_selected)

#### 6. Alpha diversity figure ####
alpha_df <- alpha_mcrA %>%
  dplyr::left_join(input_rar$map_loaded,
            by = c("sampleID")) %>%
  dplyr::mutate(
    ThawStage = factor(ThawStage.x,
                       levels = c("Stable", "Early", "Intermediate", "Advanced")),
    Core_Depth = factor(Core_Depth.x,
                        levels = c("Shallow", "Intermediate", "Deep"))
  )

fig1 <- ggplot(alpha_df,
               aes(x = ThawStage.x, y = Shannon)) +
  geom_boxplot(outlier.shape = NA, width = 0.6) +
  geom_jitter(width = 0.15, alpha = 0.6, size = 2) +
  facet_wrap(~ Core_Depth.x, nrow = 1) +
  theme_classic(base_size = 14) +
  labs(x = "Thaw Stage",
       y = "Shannon Diversity (mcrA)") +
  theme(
    strip.background = element_blank(),
    strip.text = element_text(face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  )

#### 7. Methanoregula shift?? ####
# Get ASVs belonging to Methanoregula
methano_asvs <- input_rar$taxonomy_loaded %>%
  filter(taxonomy6 == "Methanoregula") %>%
  rownames()

# Get abundance table
abund <- as.data.frame(t(input_rar$data_loaded))

# Summarize methanoregula per sample
methano_abund <- abund[, colnames(abund) %in% methano_asvs]

methano_sum <- rowSums(methano_abund)

methano_df <- data.frame(
  SampleID = rownames(abund),
  Methanoregula = methano_sum
)

# Add metadata
meta <- input_rar$map_loaded
df <- meta %>%
  mutate(SampleID = rownames(meta)) %>%
  left_join(methano_df, by = "SampleID")

# Quantify group shifts
group_means <- df %>%
  dplyr::group_by(ThawStage) %>%
  dplyr::summarise(
    mean_methano = mean(Methanoregula, na.rm=TRUE),
    mean_CH4 = mean(ch4, na.rm=TRUE),
    mean_C13 = mean(mean_13C, na.rm=TRUE)
  )

#CH4 explained by Methanoregula
model1 <- lm(ch4 ~ Methanoregula, data = df)
summary(model1)$r.squared

# Isotope data explained by Methanoregula
model2 <- lm(mean_13C ~ Methanoregula, data = df)
summary(model2)$r.squared

#### 8. Test which variables BEST predict CH4 ####
# Get top 5 genus
top5_genera <- c("Methanobacterium_B",
                 "Methanosarcina",
                 "Methanoregula",
                 "Methanothrix",
                 "MTP4")

methano_taxa <- input_rar$taxonomy_loaded %>%
  filter(taxonomy6 %in% top5_genera)

methano_asvs <- rownames(methano_taxa)

# Genus level abundnace matrix
abund <- as.data.frame(t(input_rar$data_loaded))

genus_vector <- input_rar$taxonomy_loaded$taxonomy6
names(genus_vector) <- rownames(input_rar$taxonomy_loaded)

sum(colnames(abund) %in% names(genus_vector))

abund_t <- t(abund)

abund_with_genus <- data.frame(
  Genus = genus_vector[rownames(abund_t)],
  abund_t
)

genus_abundance <- aggregate(. ~ Genus,
                             data = abund_with_genus,
                             FUN = sum)

top5_genera <- c("Methanobacterium_B",
                 "Methanosarcina",
                 "Methanoregula",
                 "Methanothrix",
                 "MTP4")

top5_genus <- genus_abundance[genus_abundance$Genus %in% top5_genera, ]

rownames(top5_genus) <- top5_genus$Genus
top5_genus <- top5_genus[, -1]

top5_genus <- t(top5_genus)

head(top5_genus)
dim(top5_genus)

# Merge with environmental data
# Add SampleID column
top5_genus_df <- data.frame(
  SampleID = rownames(top5_genus),
  top5_genus
)

meta_df <- data.frame(
  SampleID = rownames(input_rar$map_loaded),
  input_rar$map_loaded
)

# Merge
df_full <- merge(meta_df, top5_genus_df, by = "SampleID")


collar_df <- df_full %>%
  dplyr::group_by(PlotID_unique) %>%
  dplyr::summarise(
    
    ch4 = mean(ch4),
    co2 = mean(co2),
    mean_13C = mean(mean_13C),
    
    Methanoregula = sum(Methanoregula),
    Methanothrix = sum(Methanothrix),
    Methanosarcina = sum(Methanosarcina),
    Methanobacterium_B = sum(Methanobacterium_B),
  #  MTP4 = sum(MTP4),
  
    SoilTempC = mean(SoilTempC),
    SoilMoisture = mean(SoilMoisture),
    WaterTableDepth_cm = mean(WaterTableDepth_cm),
    SeasonalThawDepth_cm = mean(SeasonalThawDepth_cm),
  
    ThawStage = dplyr::first(ThawStage),
  .groups = "drop"
  )

# Test best model
# Transform ch4

collar_df$sqrt_ch4 <- sign(collar_df$ch4) * sqrt(abs(collar_df$ch4))
full_model <- lm(sqrt_ch4 ~ Methanoregula +
                   Methanothrix +
                   Methanosarcina +
                   Methanobacterium_B +
                   SoilTempC +
                   SoilMoisture +
                   WaterTableDepth_cm +
                   SeasonalThawDepth_cm +
                   ThawStage,
                 data = collar_df,
                 na.action = na.omit)

summary(full_model)

# Remove all NAs for model selection
collar_complete <- na.omit(collar_df)

full_model2 <- lm(sqrt_ch4 ~ Methanoregula +
                   Methanothrix +
                   Methanosarcina +
                   Methanobacterium_B +
                   SoilTempC +
                   SoilMoisture +
                   WaterTableDepth_cm +
                   SeasonalThawDepth_cm +
                   ThawStage,
                 data = collar_complete)

summary(full_model2)

# MOdel selection with AIC
library(MuMIn)

options(na.action = "na.fail")

model_set <- dredge(full_model2)
model_set

# Methanoregula
meth_model <- lm(sqrt_ch4 ~ Methanoregula,
                 data = collar_df)

summary(meth_model)
summary(meth_model)$r.squared

collar_13C <- collar_df %>%
  filter(!is.na(mean_13C))

meth_model2 <- lm(mean_13C ~ Methanoregula,
                 data = collar_13C)

summary(meth_model2)
summary(meth_model2)$r.squared

#### 9. Facted bar plot ####
# Barplot by sampleID with facet by variable
library(forcats)
tax_sum_genus_mcrA <- summarize_taxonomy(input = input_rar, 
                                        level = 6, 
                                        report_higher_tax = F)

bars_genus_mcrA <- plot_taxa_bars(tax_sum_genus_mcrA,
                                 input_rar$map_loaded,
                                 "sampleID",
                                 num_taxa = 5,
                                 data_only = TRUE) %>%
  mutate(taxon = fct_rev(taxon)) %>%
  left_join(., input_rar$map_loaded, by = c("group_by" = "sampleID"))


top_genus_mcrA <- bars_genus_mcrA %>%
  dplyr::group_by(taxon) %>%
  dplyr::summarise(mean = mean(mean_value)) %>%
  filter(taxon != "Other") %>%
  arrange(-mean) %>%
  mutate(taxon = as.character(taxon))

bars_genus_mcrA <- bars_genus_mcrA %>%
  mutate(taxon = factor(taxon,
                        levels = c("Other", rev(top_genus_mcrA$taxon)))) %>%
  mutate(Site = factor(Site,
                       levels = c("PP", "AM"))) %>%
  mutate(ThawStage = factor(ThawStage,
                            levels = c("Stable", "Early", "Intermediate",
                                       "Advanced")))

library(ggh4x)
ggplot(bars_genus_mcrA, aes(group_by, mean_value, fill = taxon)) +
  geom_bar(stat = "identity", colour = NA, linewidth = 0.25) +
  labs(x = "Sample", y = "Relative abundance", fill = "Genus") +
  #scale_fill_manual(values = c("grey90", brewer.pal(12, "Paired")[10:6])) +
  scale_fill_manual(values = c("grey90", "#FFFF99", "#FF7F00", "#B2DF8A", "#A6CEE3", "#1F78B4") )+
  scale_y_continuous(expand = c(0.01, 0.01)) + 
  facet_nested(~ Site + ThawStage, space = "free", scales = "free_x") +
  theme_classic() +
  theme(axis.title.y = element_text(face = "bold", size = 12),
        axis.title.x = element_blank(),
        axis.text.y = element_text(size = 10),
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.line.x = element_blank(),
        axis.line.y = element_blank(),
        strip.text = element_text(size = 10),
        strip.background = element_rect(linewidth = 0.2),
        strip.text.x = element_text(face = "bold"),
        legend.position = "right",
        legend.margin = margin(0, 0, 0, 0, unit = "pt"),
        legend.box.margin = margin(0, 0, 0, 0, unit = "pt"),
        legend.key.size = unit(0.5, "cm"))

ggsave("mcrA_genus.jpg", width = 9, height = 5)


#### 10. Ordination plot ####
set.seed(100)
dm = calc_dm(input_rar$data_loaded)
nmds <- metaMDS(dm, trymax = 200)
stressplot(nmds)
nmds$stress
# Make new dataframe with just continuous env. variables
names(input_rar$map_loaded)
d_env <- input_rar$map_loaded %>%
  dplyr::select(SoilTempC,
               # SoilMoisture, #Not significant
                WaterTableDepth_cm,
                SeasonalThawDepth_cm,
                mean_13C,
                co2, # Not significant
                ch4)
set.seed(100)
ef <- envfit(nmds, d_env, permutations = 999, na.rm = TRUE)
ef
ordiplot(nmds)
plot(ef, cex = 0.5, p.max = 0.05)
multiplier <- ordiArrowMul(ef)
multiplier
vec.df <- as.data.frame(ef$vectors$arrows * sqrt(ef$vectors$r)) %>%
  mutate(
    NMDS1 = NMDS1 * multiplier,
    NMDS2 = NMDS2 * multiplier
  ) %>%
  mutate(variables = rownames(.)) %>%
  mutate(
    shortnames = c(
      "bold(Soil~T)",
    #  "bold(Soil~M)",
      "bold(Water~Table)",
      "bold(AL)",
      "bold(delta^{13}*C~CH[4])",
      "bold(CO[2])",
      "bold(CH[4])"
    ),
    ,
    label_x = case_when(
      variables == "co2" ~ NMDS1 - 0.06,  # right
      TRUE ~ NMDS1
    ),
    label_y = case_when(
      variables == "mean_13C" ~ NMDS2 - 0.07, # down
      TRUE ~ NMDS2
    )
  )

input_rar$map_loaded$Axis01 <- vegan::scores(nmds)[,1]
input_rar$map_loaded$Axis02 <- vegan::scores(nmds)[,2] 

# Factor the thaw stages and core depths
input_rar$map_loaded$ThawStage <- factor(
  input_rar$map_loaded$ThawStage,
  levels = c("Stable", "Early", "Intermediate", "Advanced")
)

input_rar$map_loaded$Core_Depth <- factor(
  input_rar$map_loaded$Core_Depth,
  levels = c("Shallow", "Intermediate", "Deep")
)

# Site + Core Depth + Thaw Stage
micro.hulls <- ddply(input_rar$map_loaded, c("Site"), find_hull)
ggplot(input_rar$map_loaded, aes(Axis01, Axis02)) +
  geom_polygon(
    data = micro.hulls,
    aes(fill = Site),
    colour = NA,
    alpha = 0.1,
    show.legend = FALSE
  ) +
  geom_point(
    aes(colour = ThawStage, shape = Core_Depth),
    size = 4
  ) +
  geom_segment(
    data = vec.df,
    aes(x = 0, xend = NMDS1, y = 0, yend = NMDS2),
    arrow = arrow(length = unit(0.35, "cm")),
    colour = "black", alpha = 0.6,
    inherit.aes = FALSE
  ) +
  geom_text_repel(
    data = vec.df,
    aes(x = label_x, y = label_y, label = shortnames),
    size = 6, parse = TRUE
  ) +
  geom_text(
    aes(x = -1, y = 0.7, label = "stress = 0.10"),
    size = 6
  ) +
  scale_colour_manual(
    values = c(
      "Stable" = "darkblue",        # blue
      "Early" = "skyblue",         # light blue
      "Intermediate" = "goldenrod1",  # orange
      "Advanced" = "#B2182B"       # reddish orange
    )
  ) +
  scale_shape_manual(values = c(15, 16, 17)) +
  labs(
    x = "NMDS1",
    y = "NMDS2",
    colour = "Thaw Stage",
    shape = "Core Depth"
  ) +
  theme_bw(base_size = 16) +
  theme(legend.position = "right",
        axis.title = element_text(size = 14), 
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        panel.grid = element_blank())

ggsave("Ordination_Plot_mcrA.jpg", width = 10, height = 6)

