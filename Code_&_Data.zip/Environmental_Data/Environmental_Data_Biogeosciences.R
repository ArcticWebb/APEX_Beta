library(dplyr)
library(readr)
library(tidyr)
library(ggplot2)

setwd("")

#### 1. Environmental data cleaning ####
# Import environmental data
env <- read.csv("EnvironmentalData_July_nomoisture.csv")

# Import thaw stage information
ts <- read.csv("ThawStages.csv")
ts <- ts

# Join thaw stage information to env
env <- env %>%
  select(Date, Site,PlotID, SoilTempC, WaterTableDepth_cm, SeasonalThawDepth_cm) %>%
  left_join(ts, by = c("Site", "PlotID"))

# Read in soil moisture
# We are keeping soil moisture data separate because the sensor was broken in 2022
# So instead, we are using 2021 data for soil moisture
moisture <- read.csv("MoistureData.csv")

# Join thaw stage information to moisture and rename column
moisture <- moisture %>%
  left_join(ts, by = c("Site", "PlotID")) %>%
  rename(
    moisture = SoilMoisture
  )

# Factor thaw stages
env$ThawStage <- factor(env$ThawStage, levels =
                               c("Stable", "Early",
                                 "Intermediate", "Advanced"))
moisture$ThawStage <- factor(moisture$ThawStage, levels =
                          c("Stable", "Early",
                            "Intermediate", "Advanced"))

# Factor site level
env$Site <- factor(env$Site, levels = 
                     c("PP", "AM"))
moisture$Site <- factor(moisture$Site, levels = 
                     c("PP", "AM"))

# Create unique plotIDs
env$PlotID_unique <- interaction(env$Site, env$PlotID, drop = TRUE)
moisture$PlotID_unique <- interaction(moisture$Site, moisture$PlotID, drop = TRUE)

# Flip signs from water table depths
env$WaterTableDepth_cm <- -1 * env$WaterTableDepth_cm


# Get summary data

# Summarize by thaw stage
env_thawstage_summary <- env %>%
  group_by(ThawStage) %>%
  summarise(
    n_wt = sum(!is.na(WaterTableDepth_cm)),
    mean_wt = mean(WaterTableDepth_cm, na.rm = TRUE),
    se_wt = sd(WaterTableDepth_cm, na.rm = TRUE) / n_wt,
    
    n_al = sum(!is.na(SeasonalThawDepth_cm)),
    mean_al = mean(SeasonalThawDepth_cm, na.rm = TRUE),
    se_al = sd(SeasonalThawDepth_cm, na.rm = TRUE) / n_al,
    
    n_temp = sum(!is.na(SoilTempC)),
    mean_temp = mean(SoilTempC, na.rm = TRUE),
    se_temp = sd(SoilTempC, na.rm = TRUE) / n_temp
  )

env_thawstage_summary_moist <- moisture %>%
  group_by(ThawStage) %>%
  summarise(
    n_sm = sum(!is.na(moisture)),
    mean_sm = mean(moisture, na.rm = TRUE),
    se_sm = sd(moisture, na.rm = TRUE) / sqrt(n_sm)
  )

# Change sign of water table depths
env <- env %>%
  mutate(WT_new = -WaterTableDepth_cm)

# Create linear mixed effects models with unique plot IDs as random effect for repeated measurements
library(lmerTest)
model_wt  <- lmer(WT_new ~ ThawStage + (1|PlotID_unique), data = env)
model_alt <- lmer(SeasonalThawDepth_cm ~ ThawStage + (1|PlotID_unique), data = env)
model_tmp <- lmer(SoilTempC ~ ThawStage + (1|PlotID_unique), data = env)
# Remember that soil moisture is using a different dataframe
model_mo  <- lmer(moisture ~ ThawStage + (1|PlotID_unique), data = moisture)

# Get anova tables
summary(model_wt)
anova(model_wt)
summary(model_alt)
anova(model_alt)
summary(model_tmp)
anova(model_tmp)
summary(model_mo)
anova(model_mo)


#### Environmental data figures ####
library(ggplot2)
library(emmeans)
library(multcomp)
library(dplyr)


# Define colors for thaw stages
thaw_cols <- c("darkblue", "skyblue", 
               "goldenrod1", "#B2182B")

# Helper function to extract letters and y positions
get_cld_positions <- function(model, data, response_var, reverse = FALSE, offset = 0.05) {
  
  # Get emmeans and compact letter display
  emm <- emmeans(model, ~ ThawStage)
  cld_df <- cld(emm, Letters = letters, adjust = "tukey")
  
  # Clean spacing in letters
  cld_df$.group <- gsub(" ", "", cld_df$.group)
  
  # Calculate y positions
  y_vals <- data %>%
    group_by(ThawStage) %>%
    summarise(
      y_max = max(.data[[response_var]], na.rm = TRUE),
      y_min = min(.data[[response_var]], na.rm = TRUE),
      .groups = "drop"
    )
  
  # Determine offset amount relative to data range
  data_range <- diff(range(data[[response_var]], na.rm = TRUE))
  shift <- data_range * offset
  
  if (!reverse) {
    y_vals$y_pos <- y_vals$y_max + shift
  } else {
    y_vals$y_pos <- y_vals$y_min - shift
  }
  
  # Merge letters with positions
  final_df <- left_join(cld_df, y_vals, by = "ThawStage")
  
  return(final_df)
}

# Generate letter data for each model
wt_letters  <- get_cld_positions(model_wt,  env,      "WT_new", reverse = FALSE,
                                 offset = 0.15)
# Swap letters because they got mixed up for wt
wt_letters <- wt_letters %>%
  mutate(.group = case_when(
    .group == "a" ~ "b",
    .group == "b" ~ "a",
    TRUE ~ .group
  ))

alt_letters <- get_cld_positions(model_alt, env,      "SeasonalThawDepth_cm", reverse = TRUE,
                                 offset = 0.2)
st_letters  <- get_cld_positions(model_tmp, env,      "SoilTempC", reverse = FALSE,
                                 offset = 0.2)
sm_letters  <- get_cld_positions(model_mo,  moisture, "moisture", reverse = FALSE,
                                 offset = 0.15)



wt <- ggplot(env, aes(x = ThawStage, 
                      y = WT_new, 
                      fill = ThawStage)) +
  geom_boxplot(alpha = 0.8, outlier.shape = NA) +
  geom_jitter(width = 0.15, size = 2, alpha = 0.5) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.8) +
  scale_fill_manual(values = thaw_cols) +
#  scale_y_reverse() +
  geom_text(data = wt_letters,
            aes(x = ThawStage, y = y_pos, label = .group),
            inherit.aes = FALSE,
            size = 5) +
  labs(y = "Water table depth (cm)", x = NULL) +
  theme_bw(base_size = 16) +
  theme(legend.position = "none",
        axis.text.x = element_blank())
  
al <- ggplot(env, aes(x = ThawStage, 
                      y = SeasonalThawDepth_cm, 
                      fill = ThawStage)) +
  geom_boxplot(alpha = 0.8, outlier.shape = NA) +
  geom_jitter(width = 0.15, size = 2, alpha = 0.5) +
  scale_y_reverse(limits = c(-5,130)) +
  scale_fill_manual(values = thaw_cols) +
  geom_text(data = alt_letters,
            aes(x = ThawStage, y = y_pos, label = .group),
            inherit.aes = FALSE,
            size = 5) +
  coord_cartesian(clip = "off") +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.8) +
  labs(y = "Seasonal thaw depth (cm)", x = NULL) +
  theme_bw(base_size = 16)  +
  theme(legend.position = "none",
        axis.text.x = element_blank())

st <- ggplot(env, aes(x = ThawStage, 
                      y = SoilTempC, 
                      fill = ThawStage)) +
  geom_boxplot(alpha = 0.8, outlier.shape = NA) +
  geom_jitter(width = 0.15, size = 2, alpha = 0.5) +
  scale_fill_manual(values = thaw_cols) +
  geom_text(data = st_letters,
            aes(x = ThawStage, y = y_pos, label = .group),
            inherit.aes = FALSE,
            size = 5) +
  coord_cartesian(clip = "off") +
  labs(y = "Soil temperature (°C)", x = NULL) +
  theme_bw(base_size = 16) +
  theme(legend.position = "none")

sm <- ggplot(moisture, aes(x = ThawStage, 
                      y = moisture, 
                      fill = ThawStage)) +
  geom_boxplot(alpha = 0.8, outlier.shape = NA) +
  geom_jitter(width = 0.15, size = 2, alpha = 0.5) +
  scale_fill_manual(values = thaw_cols) +
  geom_text(data = sm_letters,
            aes(x = ThawStage, y = y_pos, label = .group),
            inherit.aes = FALSE,
            size = 5) +
  coord_cartesian(clip = "off") +
  labs(y = "Soil moisture (%)", x = NULL) +
  theme_bw(base_size = 16) +
  theme(legend.position = "none")

# Combine plots into 4 panels
library(patchwork)

(wt + al) / (st + sm) +
  plot_annotation(tag_levels = "a",
                  tag_suffix = ")")

#ggsave("Fig3.jpg", width = 10, height = 8)


#### 2. Isotope Data cleaning ####

# These are the isotope values extracted using a standard deviation of 10 as a cutoff
df <- read.csv("IsotopteData_SD10_FinalAnalyses.csv")
head(df)

# Convert . to NA and make sure CH4 is numeric
# Add a unique ID to each collar
df <- df %>%
  mutate(
    CH4_del13C = na_if(CH4.del13C, "."),
    CH4_del13C = as.numeric(CH4_del13C),
    CO2_del13C = na_if(CO2.del13C, "."),
    CO2_del13C = as.numeric(CO2_del13C),
    PlotID_unique = interaction(Site, PlotID, drop = TRUE)
  ) %>%
  select(-CH4.del13C, -CO2.del13C)


# Calculate mean  del13C for each unique PlotID
df_summary <- df %>%
  group_by(Site, PlotID, Method) %>%
  summarise(
    CH4_del13C_mean = mean(CH4_del13C, na.rm = TRUE),
    n_measurements_CH4 = sum(!is.na(CH4_del13C)),
    CO2_del13C_mean = mean(CO2_del13C, na.rm = TRUE),
    n_measurements_CO2 = sum(!is.na(CO2_del13C)),
    .groups = "drop"
  )

# Remove NaN rows for CH4 data
df_summary <- df_summary %>%
  filter(!is.na(CH4_del13C_mean) & !is.nan(CH4_del13C_mean))


df_final <- df_summary %>%
  group_by(Site, PlotID) %>%
  mutate(mean_13C_CH4 = mean(CH4_del13C_mean, na.rm = TRUE),
         mean_13C_CO2 = mean(CO2_del13C_mean, na.rm = TRUE)) %>%
  ungroup()

# Import thaw stages
ts <- read.csv("ThawStages.csv")

# Attach thaw stage information to the isotope data
df_final <- df_final %>%
  left_join(ts, by = c("Site", "PlotID"))

# Factor thaw stages and site names
df_final$ThawStage <- factor(df_final$ThawStage, levels =
                               c("Stable", "Early",
                                 "Intermediate", "Advanced"))

df_final$Site <- factor(df_final$Site, levels =
                          c("PP", "AM"))

# Export for analysis downstream
write.csv(df_final, "Cleaned_Isotope2.csv", row.names = FALSE)



# # Make Method its own column so that we can average values across all
# # sampling approaches
# library(tidyr)
# 
# df_final <- df_summary %>%
#   pivot_wider(
#     names_from  = Method,
#     values_from = c(CH4_del13C_mean, CO2_del13C_mean)
#   )
# 
# # Calculate average for all sampling methods
# # Calculate standard deviation of this average for all sampling methods
# df_final <- df_final %>%
#   rowwise() %>%
#   mutate(
#     mean_13C_CH4 = mean(c_across(starts_with("CH4_del13C_mean_")), na.rm = TRUE),
#     sd_13C_CH4   = sd(c_across(starts_with("CH4_del13C_mean_")), na.rm = TRUE),
# 
#     mean_13C_CO2 = mean(c_across(starts_with("CO2_del13C_mean_")), na.rm = TRUE),
#     sd_13C_CO2   = sd(c_across(starts_with("CO2_del13C_mean_")), na.rm = TRUE)
#   ) %>%
#   ungroup()
# 
# # Remove rows with no isotope data at all
# df_final <- df_final %>%
#   filter(!is.na(mean_13C_CH4) & !is.nan(mean_13C_CH4))
# 
# # Collapse into one row per collar
# df_final <- df_final %>%
#   group_by(Site, PlotID) %>%
#   summarise(
#     across(everything(), ~ {
#       if (is.numeric(.)) mean(., na.rm = TRUE) else first(.)
#     }),
#     .groups = "drop"
#   )
# 
# 
# # See how many collars had porewater CH4 data 
# df_final %>%
#   filter(!is.na(CH4_del13C_mean_Deep) | !is.na(CH4_del13C_mean_Shallow)) %>%
#   distinct(Site, PlotID) %>%
#   nrow()
# # 19 collars had porewater data
# df_final %>%
#   filter(!is.na(CH4_del13C_mean_Deep) | !is.na(CH4_del13C_mean_Shallow)) %>%
#   distinct(Site, PlotID) %>%
#   count(Site)
# # 12 from AM and 7 from PP
# 
# 
# # See how many plots had chamber CH4 data
# df_final %>%
#   filter(!is.na(CH4_del13C_mean_Chamber)) %>%
#   distinct(Site, PlotID) %>%
#   nrow()
# # 14 collars had chamber data
# df_final %>%
#   filter(!is.na(CH4_del13C_mean_Chamber)) %>%
#   distinct(Site, PlotID) %>%
#   count(Site)
# # 8 from AM and 6 from PP
# 
# 
# # Import thaw stages
# ts <- read.csv("ThawStages.csv")
# 
# # Attach thaw stage information to the isotope data
# df_final <- df_final %>%
#   left_join(ts, by = c("Site", "PlotID"))
# 
# # Factor thaw stages and site names
# df_final$ThawStage <- factor(df_final$ThawStage, levels =
#                                c("Stable", "Early",
#                                  "Intermediate", "Advanced"))
# 
# df_final$Site <- factor(df_final$Site, levels =
#                                c("PP", "AM"))
# 
# # Export for analysis downstream
# write.csv(df_final, "Cleaned_Isotope2.csv", row.names = FALSE)
#### Begin here for isotope data ####

df_final <- read.csv("Cleaned_Isotope2.csv")

# Create unique Plot ID
df_final <- df_final %>%
  mutate(
PlotID_unique = interaction(Site, PlotID, drop = TRUE)
)


# Factor methods column
df_final$Method <- factor(df_final$Method, levels = c("Chamber",
                                                    "Shallow",
                                                    "Deep"))

# Rename method column to "Depth" since we are more interested in that relationship
df_final <- df_final %>%
  rename(
    Depth = Method
  )

#### Calculate apparent fractionation factor (α) ####
# Must do individually for surface, shallow, and deep
df_frac <- df_final %>%
  filter(!is.na(CH4_del13C_mean),
         !is.na(CO2_del13C_mean)) %>%
  mutate(
    alpha_CO2_CH4 = (CO2_del13C_mean + 1000) /
      (CH4_del13C_mean + 1000),
    delta_13C_diff = CO2_del13C_mean - CH4_del13C_mean
  )

# Does pathway differ by depth
aov(alpha_CO2_CH4 ~ Depth, data = df_frac)
# Does thaw affect pathway differently by depth
lm(alpha_CO2_CH4 ~ ThawStage * Depth, data = df_frac)

# Get mean del13C-CH4 by depth
# Remove stable & early thaw stage due to lack of observations
df_frac %>%
  filter(ThawStage != "Early",
         ThawStage != "Stable") %>%
  dplyr::group_by(Depth) %>%
  dplyr::summarise(mean_d13C = mean(CH4_del13C_mean))

# Only remove stable
df_frac %>%
  filter(ThawStage != "Early") %>%
  dplyr::group_by(Depth) %>%
  dplyr::summarise(mean_d13C = mean(CH4_del13C_mean))


# Estimate % oxidation using Rayleigh Fractionation Model
delta0 <- -62.3 # Deep methane average from above
delta_obs <- -54.5 # Chamber flux average from above, includes early thaw
epsilon <- -15

f <- exp((delta_obs - delta0) / epsilon)
percent_oxidized <- (1 - f) * 100
percent_oxidized
# ~40% of methane from deep soils is oxidized by the time
# it reaches the surface! Cool!

# Calculate methane oxidation per thaw stage
df_ox_ds <- df_frac %>%
  dplyr::select(Site, PlotID, Depth, CH4_del13C_mean, ThawStage) %>%
  pivot_wider(names_from = Depth,
              values_from = CH4_del13C_mean) %>%
  filter(!is.na(Deep) & !is.na(Chamber)) %>%
  mutate(
    epsilon = -15,
    f = exp((Chamber - Deep) / epsilon),
    percent_oxidized = (1 - f) * 100
  )

df_ox_ds %>% 
  group_by(ThawStage) %>%
  summarise(
    ox = mean(percent_oxidized)
  )

# Calculate difference metric (Δ¹³C)
df_pathway <- df_pathway %>%
  mutate(
    delta_13C_diff = CO2_del13C_mean - CH4_del13C_mean
  )

# Try out multiple Epsilon values at request of reviewer 2
df_ox_ds <- df_frac %>%
  select(Site, PlotID, Depth, CH4_del13C_mean, ThawStage) %>%
  filter(Depth %in% c("Chamber", "Deep")) %>%
  pivot_wider(
    names_from = Depth,
    values_from = CH4_del13C_mean
  ) %>%
  filter(!is.na(Deep), !is.na(Chamber))

# Calculate Rayleigh estimate
df_ox_ds <- df_ox_ds %>%
  mutate(
    epsilon = -15,
    f = exp((Chamber - Deep) / epsilon),
    percent_oxidized = (1 - f) * 100
  )

# Summarize resulting Rayleigh values
df_ox_ds %>%
  group_by(ThawStage) %>%
  summarise(
    n = n(),
    mean_oxidation = mean(percent_oxidized),
    sd_oxidation = sd(percent_oxidized)
  )

# Bootstrap
library(boot)

boot_fun <- function(data, indices) {
  d <- data[indices, ]
  mean(d$percent_oxidized, na.rm = TRUE)
}

set.seed(123)

boot_res <- boot(
  data = df_ox_ds,
  statistic = boot_fun,
  R = 5000
)

boot_res
boot.ci(boot_res, type = c("perc", "bca"))


# E sensitivity analysis
epsilon_values <- seq(-5, -25, by = -1)

sensitivity <- expand.grid(
  epsilon = epsilon_values,
  sample = seq_len(nrow(df_ox_ds))
) %>%
  left_join(
    df_ox_ds %>%
      mutate(sample = row_number()) %>%
      dplyr::select(sample, Site, PlotID, ThawStage, Deep, Chamber),
    by = "sample"
  ) %>%
  mutate(
    f = exp((Chamber - Deep) / epsilon),
    percent_oxidized = (1 - f) * 100
  )

sensitivity %>%
  group_by(epsilon) %>%
  summarise(
    mean_apparent_oxidation = mean(percent_oxidized),
    min_apparent_oxidation = min(percent_oxidized),
    max_apparent_oxidation = max(percent_oxidized)
  ) %>%
  print(n = 21)

#### Isotope statistics ####
# Because methods are measured within the same plot, use linear mixed model
library(lme4)
library(lmerTest)

# First, let's check to see how many observations are in each thaw stage x method
table(df_final$ThawStage, df_final$Depth)
# So we don't have any porewater data from the stable thaw stage
# Let's drop it from our modeling 
df_thaw <- df_final %>%
  filter(ThawStage != "Stable")

# Let's change "Chamber" to "Surface" to describe depth instead of methods
df_thaw$Depth <- recode(df_thaw$Depth,
                        "Chamber" = "Surface")
# Refactor
df_thaw$Depth <- factor(df_thaw$Depth,
                        levels = c("Surface", "Shallow", "Deep"))
df_thaw$ThawStage <- factor(df_thaw$ThawStage,
                        levels = c("Early", "Intermediate", "Advanced"))




# Q1: Do isotope values differ across thaw stages?
model_thaw <- lmer(CH4_del13C_mean ~ ThawStage + (1 | PlotID_unique),
                   data = df_thaw)

anova(model_thaw)
# Post-hoc
#library(emmeans)
emmeans(model_thaw, pairwise ~ ThawStage)



# Q2: Do isotope values differ with depth?
# This model tests whether chamber, deep, and shallow differ
model_depth <- lmer(CH4_del13C_mean ~ Depth + (1 | PlotID_unique),
                     data = df_thaw)

summary(model_depth)
anova(model_depth)
emmeans(model_depth, pairwise ~ Depth)


# Q3: Does depth effect depend on thaw stage?
model_interaction <- lmer(CH4_del13C_mean ~ Depth * ThawStage + 
                            (1 | PlotID_unique),
                          data = df_thaw)

anova(model_interaction)


# # Q4: Using mean 13C values instead of raw methods
# model_mean <- lm(mean_13C ~ ThawStage, data = df_final)
# anova(model_mean)

# Check assumptions
# Model 1
plot(model_thaw)
qqnorm(resid(model_thaw))
qqline(resid(model_thaw))
# Model 2
plot(model_depth)
qqnorm(resid(model_depth))
qqline(resid(model_depth))
# Model 3
plot(model_interaction)
qqnorm(resid(model_interaction))
qqline(resid(model_interaction))


#### Isotope data figures ####
#library(ggplot2)

thaw_cols_nostable <- c("skyblue", 
               "goldenrod1", "#B2182B")

ggplot(df_thaw, aes(x = CH4_del13C_mean, y = Depth, 
                    color = ThawStage, 
                    group = ThawStage)) +
  stat_summary(fun = mean, geom = "point", size = 4,
               position = position_dodge(width = 0.3)) +
  # stat_summary(fun = mean, geom = "line",
  #              position = position_dodge(width = 0.3),
  #              linewidth = 1.2) +
  stat_summary(fun.data = mean_se, geom = "errorbarh",
               height = 0.1,
               position = position_dodge(width = 0.3),
               linewidth = 1.2) +
  scale_color_manual(values = thaw_cols_nostable) +
  scale_x_continuous(position = "top", trans = "reverse") +   # moves axis to top and flips axis
  scale_y_discrete(limits = rev(levels(df_thaw$Depth))) +  # depth increases downward
  theme_classic(base_size = 20) +
  geom_vline(xintercept = c(-50, -65),
             linetype = "dashed",
             color = "black",
             linewidth = 0.8) +
  xlab(expression(delta^13*C~-CH[4]~("\u2030"))) +
  ylab("Soil depth") +
  annotate("text", x = -57.5, y = Inf,
           label = "Acetoclastic",
           vjust = 1.5, size = 6) +
  
  annotate("text", x = -75, y = Inf,
           label = "Hydrogenotrophic",
           vjust = 1.5, size = 6) +
  coord_cartesian(clip = "off") +
  annotate("segment",
           x = -70, xend = -63,          # right → left (enrichment)
           y = "Deep", yend = "Surface",  # deep → shallow
           arrow = arrow(length = unit(0.25, "cm")),
           linewidth = 1,
           color = "forestgreen") +
  annotate("text",
           x = -67, y = "Shallow",
           label = "Oxidation",
           size = 5,
           hjust = -0.02,
           color = "forestgreen") +
  theme(
    legend.title = element_blank(),
    axis.title.y = element_text(size =)
  )



ggsave("Manuscript/Isotope_noline_v2.jpg", width = 10, height = 7)

# Plot Isotope values

df_frac_nostable <- df_frac %>%
  filter(ThawStage != "Stable")
levels(df_frac_nostable$Depth)[levels(df_frac_nostable$Depth) == "Chamber"] <- "Surface"
p1 <- ggplot(df_frac_nostable,
       aes(x = Depth,
           y = alpha_CO2_CH4,
           fill = Depth)) +
  geom_boxplot(alpha = 0.8, outliers = FALSE,
               show.legend = FALSE) +
  geom_jitter(width = 0.1, size = 2,
              show.legend = FALSE) +
  geom_hline(yintercept = 1.055, linetype = "dashed") +
  geom_hline(yintercept = 1.065, linetype = "dashed") +
  annotate("text",
           x = 0.1, y = 1.052,
           label = "Acetoclastic",
           hjust = -0.1, size = 4,
           fontface = "bold") +
  annotate("text",
           x = 0.2, y = 1.060,
           label = "Mixed",
           hjust = -0.1, size = 4,
           fontface = "bold") +
  annotate("text",
           x = 0.1, y = 1.068,
           label = "Hydrogenotrophic",
           hjust = -0.1, size = 4,
           fontface = "bold") +
  annotate("segment",
           x = 2.45, xend = 1.2,          # deep → surface
           y = 1.075, yend = 1.06,  # low → high α
           arrow = arrow(length = unit(0.25, "cm")),
           linewidth = 1,
           color = "forestgreen") +
  
  annotate("text",
           x = 2, y = 1.071,
           label = "Oxidation",
           angle = 47,
           size = 4,
           color = "forestgreen") +
  scale_fill_manual(values = c("cornflowerblue",
                               "saddlebrown",
                               "gray30")) +
  theme_bw(base_size = 16) +
  coord_cartesian(clip = "off") +
  #labs(y = expression(alpha[CO[2]-CH[4]])) +
  labs(y = expression(alpha[C])) +
  theme(
    axis.title.y = element_text(size = 18),
    axis.title.x = element_blank()
  )
p1
ggsave("Manuscript/FractionationDepth.jpg", width = 7, height = 6)

# Thaw stage
thaw_cols <- c("darkblue", "skyblue", 
                        "goldenrod1", "#B2182B")
df_frac_nostable$ThawStage <- factor(df_frac_nostable$ThawStage, levels = c(
                                                          "Early",
                                                          "Intermediate",
                                                          "Advanced"))

df_frac_nostable <- df_frac_nostable[df_frac_nostable$Depth == "Deep",]
p2 <- ggplot(df_frac_nostable,
       aes(x = ThawStage,
           y = alpha_CO2_CH4,
           fill = ThawStage)) +
  geom_boxplot(alpha = 0.8, outliers = FALSE,
               show.legend = FALSE) +
  geom_jitter(width = 0.1, size = 2,
              show.legend = FALSE) +
  geom_hline(yintercept = 1.055, linetype = "dashed") +
  geom_hline(yintercept = 1.065, linetype = "dashed") +
  annotate("text",
           x = 0.1, y = 1.054,
           label = "Acetoclastic",
           hjust = -0.1, size = 4,
           fontface = "bold") +
  annotate("text",
           x = 0.2, y = 1.060,
           label = "Mixed",
           hjust = -0.1, size = 4,
           fontface = "bold") +
  annotate("text",
           x = 0.1, y = 1.068,
           label = "Hydrogenotrophic",
           hjust = -0.1, size = 4,
           fontface = "bold") +
  annotate("segment",
           x = 2.6, xend = 1.2,          # deep → surface
           y = 1.075, yend = 1.06,  # low → high α
           arrow = arrow(length = unit(0.25, "cm")),
           linewidth = 1,
           color = "forestgreen") +
  
  annotate("text",
           x = 2.3, y = 1.0745,
           label = "Oxidation",
           angle = 47,
           size = 4,
           color = "forestgreen") +
  scale_fill_manual(values = thaw_cols_nostable) +
  theme_bw(base_size = 16) +
  #labs(y = expression(alpha[CO[2]-CH[4]])) +
  labs(y = expression(alpha[C])) +
  theme(
    axis.title.y = element_text(size = 18),
    axis.title.x = element_blank()
  )
p2

#library(patchwork)
p1 + p2 +
  plot_annotation(tag_levels = "a",
                  tag_suffix = ")")

ggsave("Fractionation_Depth_and_ThawStage_v2.jpg", width = 11, height = 6)


#### 3. CO2/CH4 fluxes ####
#### Process raw flux data ####
library(tidyverse)
library(data.table)
library(dplyr)
library(stringr)
library(lubridate)
library(openxlsx)


# Combine all .dat files 
dat_files <- list.files(
  path = "July2022FluxData/", 
  pattern = "\\.dat$", 
  full.names = TRUE, 
  recursive = TRUE
)
dat <- map_dfr(dat_files, function(file) {
  message("Reading: ", file)
  
  df <- tryCatch({
    fread(file, data.table = FALSE, fill = TRUE)
  }, error = function(e) {
    message("Error reading ", file, ": ", e$message)
    return(NULL)
  })
  
  # If only one column, split it
  if (ncol(df) == 1) {
    df_split <- str_split(df[[1]], "\\s+", simplify = TRUE)
    df <- as.data.frame(df_split, stringsAsFactors = FALSE)
    
    # Use first row as header if it looks like column names
    if (all(!duplicated(df[1, ])) && all(!is.na(df[1, ]))) {
      names(df) <- df[1, ]
      df <- df[-1, , drop = FALSE]
    }
  }
  
  # 🔹 Force all columns to character to avoid type conflicts
  df <- df %>% mutate(across(everything(), as.character))
  
  # Add file metadata
  df$SourceFile <- basename(file)
  df$Folder <- dirname(file)
  
  return(df)
})

# Combine csv files 
csv_files <- list.files(
  path = "July2022FluxData/", 
  pattern = "\\.csv$", 
  full.names = TRUE, 
  recursive = TRUE
)
csv <- map_dfr(csv_files, function(file) {
  message("Reading: ", file)
  
  df <- tryCatch({
    read.csv(file, stringsAsFactors = FALSE)
  }, error = function(e) {
    message("  ⚠️ Error reading ", file, ": ", e$message)
    return(NULL)
  })
  
  # Skip empty files
  if (is.null(df) || nrow(df) == 0) {
    message("  ⚠️ Skipping empty file: ", file)
    return(NULL)
  }
  
  # Force all columns to character
  df <- df %>% mutate(across(everything(), as.character))
  
  # Add metadata
  df$SourceFile <- basename(file)
  df$Folder <- dirname(file)
  
  return(df)
})


# To increase processing speed, convert dataframes to tables
setDT(dat)
setDT(csv)

# Make variables numeric and remove any white space
dat[, EPOCH_TIME := as.numeric(trimws(EPOCH_TIME))]
csv[, start_fit  := as.numeric(trimws(start_fit))]
csv[, end_fit    := as.numeric(trimws(end_fit))]


# Initialize list to hold results
res_list <- vector("list", nrow(csv))

for (i in seq_len(nrow(csv))) {
  row <- csv[i]
  
  # Which species column to use in dat
  species_col <- ifelse(row$Species == "CH4", "CH4", "CO2")
  
  # Filter dat rows within start and end EPOCH_TIME
  tmp <- dat[EPOCH_TIME >= row$start_fit & EPOCH_TIME <= row$end_fit,
             .(EPOCH_TIME, Concentration = get(species_col))]
  
  # Add CSV metadata
  tmp[, `:=`(
    Species = row$Species,
    Time.Code = row$Time.Code,
    Comment = row$Comment,
    start_fit = row$start_fit,
    end_fit = row$end_fit
  )]
  
  res_list[[i]] <- tmp
  if (i %% 100 == 0) message("Processed row ", i, " of ", nrow(csv))
}

# Combine everything into one large dataframe
flux_raw_combined <- rbindlist(res_list, use.names = TRUE, fill = TRUE)

# Remove unnecessary environment items
rm(csv, dat, row, tmp, csv_files, dat_files, i, species_col)

# Trim white space in Comment column
flux_raw_combined[, Comment := trimws(Comment)]

# Fill missing Comment rows based on Time.Code
# Convert empty rows to NA first
flux_raw_combined[Comment == "", Comment := NA_character_]

# Now fill empty comments
flux_raw_combined[
  ,
  Comment := Comment[!is.na(Comment)][1],
  by = Time.Code
]


# flux_raw_combined <- flux_raw_combined %>%
#   mutate(Comment = na_if(Comment, ""))
# 
# flux_raw_combined <- flux_raw_combined %>%
#   group_by(Time.Code) %>%
#   fill(Comment, .direction = "downup") %>%
#   ungroup()

# Remove rows that are not samples
# This code is case sensitive
flux_raw_combined <- flux_raw_combined[
  grepl("AM|PP", flux_raw_combined$Comment)
]

# Check what values remain
unique(flux_raw_combined$Comment)

# Fix typos
flux_raw_combined[Comment == "PPSD3.DARO",
                  Comment := "PPSD3.DARK"]
flux_raw_combined[Comment == "PPSD4",
                  Comment := "PPSD4.AMB"]
flux_raw_combined[Comment == "PP",
                  Comment := "PPC4.AMB"]
# See unique values
unique(flux_raw_combined$Comment)
# all the plot names look good

# # Pull out PPSD4 real quick
# ppsd4 <- flux_raw_combined %>%
#   filter(Comment == "PPSD4" | Comment == "PPSD4.DARK" | Comment == "PPSD4.AMB")
# unique(ppsd4$Comment)
# # Check which values are missing
# ppsd4[, .N, by = .(Comment, Time.Code)]
# 
# table <- as.data.frame(flux_raw_combined[, .N, by = .(Comment, Time.Code)])


# Create Site column
flux_raw_combined$Site <- dplyr::case_when(
  grepl("^AM", flux_raw_combined$Comment, ignore.case = TRUE) ~ "AM",
  grepl("^PP", flux_raw_combined$Comment, ignore.case = TRUE) ~ "PP",
  TRUE ~ NA_character_
)

# Remove spaces in Time column
flux_raw_combined$Time.Code <- trimws(flux_raw_combined$Time.Code)
flux_raw_combined$EPOCH_TIME <- trimws(flux_raw_combined$EPOCH_TIME)


# Create Date, Year, and Month columns using Time.Code
flux_raw_combined <- flux_raw_combined %>%
  mutate(
    # Parse to datetime
    Time.Code = ymd_hms(Time.Code),
    
    # Extract parts
    Date = format(Time.Code, "%m/%d/%Y"),
    Year = year(Time.Code),
    Month = format(Time.Code, "%B")   # Full month name (e.g., "September")
  )

# Create a light condition column (dark vs light flux measurement)
flux_raw_combined <- flux_raw_combined %>%
  mutate(
    Light = case_when(
      str_detect(Comment, "\\.AMB$")  ~ "light",
      str_detect(Comment, "\\.DARK$") ~ "dark",
      TRUE ~ NA_character_
    )
  ) %>%
  mutate(
    PlotID = str_remove(Comment, "\\..*$")
  )

# Create plotID column
# Now, using raw concentration data, we can calculate a flux

# Define constants
v <- 0.23             # m³, chamber volume
a <- 0.36             # m², ground area
gc <- 8.3144621       # J mol⁻¹ K⁻¹, gas constant
p <- 101325           # Pa, atmospheric pressure
t <- 293.15           # Kelvin, internal chamber temp

# Make flux dataframe wide format
flux_raw_combined <- flux_raw_combined %>%
  mutate(
    EPOCH_TIME = as.numeric(EPOCH_TIME),
    Concentration = as.numeric(Concentration)
  ) %>%
  pivot_wider(
    names_from = Species,
    values_from = Concentration
  )


# Calculate the actual flux
# Remove first and last 5 seconds of data
flux <- flux_raw_combined %>%
  mutate(
    EPOCH_TIME = as.numeric(EPOCH_TIME),
    CO2 = as.numeric(CO2),
    CH4 = as.numeric(CH4)
  ) %>%
  filter(!is.na(EPOCH_TIME), !is.na(CO2), !is.na(CH4)) %>%
  
  group_by(Site, PlotID, Date, Year, Month, Light) %>%
  
  # Normalize time within each chamber deployment
  mutate(
    norm_seconds = EPOCH_TIME - min(EPOCH_TIME, na.rm = TRUE),
    max_seconds = max(norm_seconds, na.rm = TRUE)
  ) %>%
  
  # 🔥 Remove first and last 5 seconds
  filter(
    norm_seconds >= 5,
    norm_seconds <= (max_seconds - 5)
  ) %>%
  
  summarise(
    co2_slope = if (n() >= 2) coef(lm(CO2 ~ norm_seconds))[2] else NA_real_,
    ch4_slope = if (n() >= 2) coef(lm(CH4 ~ norm_seconds))[2] else NA_real_,
    ch4_model = list(lm(CH4 ~ norm_seconds)),
    ch4_r2 = summary(ch4_model[[1]])$r.squared,
    .groups = "drop"
  ) %>%
  
  mutate(
    co2_flux_umol_m2_s = (co2_slope * p * v) / (gc * t * a),
    ch4_flux_umol_m2_min = (ch4_slope * p * v) / (gc * t * a) * 60
  )

# Looking at the flux data, we notice that a few of the advanced thaw stage collars
# had extremely high methane uptake values that seem very unlikely
# We want to explore the raw data further to see what's going on

darkflux <- flux %>%
  filter(Light == "dark")

# Let's check AMSA2 first
amsa2 <- flux_raw_combined %>%
  mutate(
    norm_seconds = EPOCH_TIME - min(EPOCH_TIME, na.rm = TRUE),
    max_seconds = max(norm_seconds, na.rm = TRUE)
  ) %>%
  filter(PlotID == "AMSA2" & Date == "07/12/2022" & Light == "dark")

# This one actually looks normal
amsa2.2 <- flux_raw_combined %>%
  mutate(
    norm_seconds = EPOCH_TIME - min(EPOCH_TIME, na.rm = TRUE),
    max_seconds = max(norm_seconds, na.rm = TRUE)
  ) %>%
  filter(PlotID == "AMSA2" & Date == "07/05/2022" & Light == "dark")


ggplot(amsa2, aes(norm_seconds, CH4)) +
  geom_point() +
  geom_smooth(method = "lm")
# Trend is extremely linear, however, the starting concentration of CH4 is
# already > 13ppm. This means CH4 likely diffused into the soil or was oxidated
# so we should not include that value in our final fluxes 

amch3 <- flux_raw_combined %>%
  mutate(
    norm_seconds = EPOCH_TIME - min(EPOCH_TIME, na.rm = TRUE),
    max_seconds = max(norm_seconds, na.rm = TRUE)
  ) %>%
  filter(PlotID == "AMCH3" & Date == "07/12/2022" & Light == "dark")

amch3.2<- flux_raw_combined %>%
  mutate(
    norm_seconds = EPOCH_TIME - min(EPOCH_TIME, na.rm = TRUE),
    max_seconds = max(norm_seconds, na.rm = TRUE)
  ) %>%
  filter(PlotID == "AMCH3" & Date == "07/05/2022" & Light == "dark")


ggplot(amch3, aes(norm_seconds, CH4)) +
  geom_point() +
  geom_smooth(method = "lm")
# Same issue as last collar. Starting CH4 was way too high



# Remove irrelevant columns
flux <- flux %>%
  dplyr::select(-ch4_model)

# Remove outliers
flux <- flux %>%
  filter(ch4_flux_umol_m2_min > -5)

# OLD CODE
# THIS DID NOT REMOVE FIRST AND LAST 5 SECONDS
# flux2 <- flux_raw_combined %>%
#   mutate(
#     EPOCH_TIME = as.numeric(EPOCH_TIME),
#     CO2 = as.numeric(CO2),
#     CH4 = as.numeric(CH4)
#   ) %>%
#   filter(!is.na(EPOCH_TIME), !is.na(CO2), !is.na(CH4)) %>%
#   group_by(Site, PlotID, Date, Year, Month, Light) %>%
#   mutate(norm_seconds = EPOCH_TIME - min(EPOCH_TIME, na.rm = TRUE)) %>%
#   summarise(
#     co2_slope = if (n() >= 2) coef(lm(CO2 ~ norm_seconds))[2] else NA_real_,
#     ch4_slope = if (n() >= 2) coef(lm(CH4 ~ norm_seconds))[2] else NA_real_,
#     .groups = "drop"
#   ) %>%
#   mutate(
#     co2_flux_umol_m2_s = (co2_slope * p * v) / (gc * t * a),
#     ch4_flux_umol_m2_min = (ch4_slope * p * v) / (gc * t * a) * 60
#   )

# Remove unnecessary items in environment
rm(a, gc, p, t, v)

# Add Light info to the fluxes
# Then collapse everything so that there is one date per collar
flux <- flux %>%
  pivot_wider(
    names_from = Light,
    values_from = c(co2_flux_umol_m2_s, ch4_flux_umol_m2_min)
  ) %>%
  dplyr::select(-co2_slope, -ch4_slope) %>%
  group_by(Site, PlotID, Date, Year, Month) %>%
  summarise(
    across(everything(), ~ coalesce(.[!is.na(.)][1], NA_real_)),
    .groups = "drop"
  )

# Export the final cleaned fluxes
#write.csv(flux, "Environmental_Data/July2022BetaFluxes.csv", row.names = FALSE)


#### CO2/CH4 figures ####
library(stringr)
flux <- read.csv("July2022BetaFluxes.csv") %>%
  dplyr::mutate(
    PlotID = str_sub(PlotID, 3)
  ) %>%
  dplyr::select(-co2_flux_umol_m2_s_dark, 
         -ch4_flux_umol_m2_min_light)

# Append thaw stage data
ts <- read.csv("ThawStages.csv") 

flux <- flux %>%
  left_join(ts, by = c("Site", "PlotID"))

flux$PlotID_unique <- interaction(flux$Site, flux$PlotID)
flux$PlotID_unique <- as.character(flux$PlotID_unique)

# Change units of CH4 to standardize with CO2
flux$ch4_flux_umol_m2_s_dark <- flux$ch4_flux_umol_m2_min_dark / 60

# Summary table of the data
flux_summary <- flux %>%
  dplyr::group_by(ThawStage) %>%
  dplyr::summarise(
    mean_co2 = mean(co2_flux_umol_m2_s_light, na.rm = TRUE),
    se_co2 = sd(co2_flux_umol_m2_s_light, na.rm = TRUE),
    
    mean_ch4 = mean(ch4_flux_umol_m2_min_dark, na.rm = TRUE),
    se_ch4 = sd(ch4_flux_umol_m2_min_dark, na.rm = TRUE),
    
    mean_ch4_s = mean(ch4_flux_umol_m2_s_dark, na.rm = TRUE),
    se_ch4_s = sd(ch4_flux_umol_m2_s_dark, na.rm = TRUE)
  )
# Standard error calculation
flux_summary <- flux %>%
  dplyr::group_by(ThawStage) %>%
  dplyr::summarise(
    n_co2 = sum(!is.na(co2_flux_umol_m2_s_light)),
    mean_co2 = mean(co2_flux_umol_m2_s_light, na.rm = TRUE),
    se_co2 = sd(co2_flux_umol_m2_s_light, na.rm = TRUE) / sqrt(n_co2),
    
    n_ch4 = sum(!is.na(ch4_flux_umol_m2_min_dark)),
    mean_ch4 = mean(ch4_flux_umol_m2_min_dark, na.rm = TRUE),
    se_ch4 = sd(ch4_flux_umol_m2_min_dark, na.rm = TRUE) / sqrt(n_ch4),
    
    n_ch4_s = sum(!is.na(ch4_flux_umol_m2_s_dark)),
    mean_ch4_s = mean(ch4_flux_umol_m2_s_dark, na.rm = TRUE),
    se_ch4_s = sd(ch4_flux_umol_m2_s_dark, na.rm = TRUE) / sqrt(n_ch4_s)
  )
flux_summary2 <- flux %>%
  dplyr::group_by(Site) %>%
  dplyr::summarise(
    mean_co2 = mean(co2_flux_umol_m2_s_light, na.rm = TRUE),
    se_co2 = sd(co2_flux_umol_m2_s_light, na.rm = TRUE),
    
    mean_ch4 = mean(ch4_flux_umol_m2_min_dark, na.rm = TRUE),
    sd_ch4 = sd(ch4_flux_umol_m2_min_dark, na.rm = TRUE)
  )

# Factor site and thaw stage
flux$ThawStage <- factor(flux$ThawStage, levels = c("Stable",
                                                    "Early",
                                                    "Intermediate",
                                                    "Advanced"))
flux$Site <- factor(flux$Site, levels = c("PP", "AM"))

# Transform CH4 data
flux <- flux %>%
  dplyr::mutate(
    ch4_flux_sqrt = sign(ch4_flux_umol_m2_s_dark) *
      sqrt(abs(ch4_flux_umol_m2_s_dark))
  )


# Plot the data
thaw_cols <- c("darkblue", "skyblue", 
               "goldenrod1", "#B2182B")

# Get letters for plots
library(lmerTest)
library(multcomp)
mod_co2 <- lmer(co2_flux_umol_m2_s_light ~ ThawStage + (1|PlotID_unique),
                  data = flux)

mod_ch4 <- lmer(ch4_flux_sqrt ~ ThawStage + (1|PlotID_unique),
                  data = flux)

co2_letters <- get_cld_positions(mod_co2, flux,
                                 "co2_flux_umol_m2_s_light",
                                 reverse = FALSE,
                                 offset = 0.10)

ch4_letters <- get_cld_positions(mod_ch4, flux,
                                 "ch4_flux_sqrt",
                                 reverse = FALSE,
                                 offset = 0.10)


# CO2 figure
co2 <- ggplot(flux, aes(x = ThawStage, y = co2_flux_umol_m2_s_light, fill = ThawStage)) +
  geom_boxplot(alpha = 0.7, outliers = FALSE) +
  geom_jitter(width = 0.15, alpha = 0.6, show.legend = FALSE) +
  scale_fill_manual(values = thaw_cols) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.8,
             color = "black") +
  geom_text(data = co2_letters,
            aes(x = ThawStage, y = y_pos, label = .group),
            inherit.aes = FALSE,
            size = 6) +
  coord_cartesian(clip = "off") +
  theme_bw(base_size = 18) +
  theme(
    legend.title = element_blank(),
    axis.title.x = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  ) +
  labs(
    y = expression(CO[2]~flux~(mu*mol~m^-2~s^-1))
  )

# CH4 figure
ch4 <- ggplot(flux, aes(x = ThawStage, y = ch4_flux_sqrt, fill = ThawStage)) +
  geom_boxplot(alpha = 0.7, outliers = FALSE) +
  geom_jitter(width = 0.15, alpha = 0.6,show.legend = FALSE) +
  scale_fill_manual(values = thaw_cols) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.8,
             color = "black") +
  geom_text(data = ch4_letters,
            aes(x = ThawStage, y = y_pos, label = .group),
            inherit.aes = FALSE,
            size = 6) +
  coord_cartesian(clip = "off") +
  theme_bw(base_size = 18) +
  theme(
    legend.title = element_blank(),
    axis.title.x = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  ) +
  labs(
    y = expression(sqrt("|" * CH[4]~flux~(mu*mol~m^-2~s^-1)* "|"))
  )

library(patchwork)
(co2 + ch4)  +
  plot_annotation(tag_levels = "a",
                 # tag_prefix = "(",
                  tag_suffix = ")")

#ggsave("CO2CH4.jpg", width = 10, height = 7)

#### CO2/CH4 statistics ####

co2ch4_summary <- flux %>%
  group_by(ThawStage) %>%
  summarise(
    meanco2 = mean(co2_flux_umol_m2_s_light, na.rm = TRUE),
    seco2 = sd(co2_flux_umol_m2_s_light, na.rm = TRUE),
    
    meanch4 = mean(ch4_flux_umol_m2_min_dark, na.rm = TRUE),
    sech4 = sd(ch4_flux_umol_m2_min_dark, na.rm = TRUE)
  )

head(flux)


# CO2 - linear mixed model with repeated measurements
library(lme4)
library(lmerTest)

mod_co2 <- lmer(co2_flux_umol_m2_s_light ~ ThawStage + 
                  (1 | PlotID_unique),
                data = flux)

summary(mod_co2)
anova(mod_co2)

# Post hoc
library(emmeans)

emmeans(mod_co2, pairwise ~ ThawStage)

# Check model assumptions
plot(mod_co2)
qqnorm(resid(mod_co2))
qqline(resid(mod_co2))



# CH4 - linear mixed model with repeated measurements
# signed-square root transformation of CH4

mod_ch4 <- lmer(ch4_flux_sqrt ~ ThawStage +
                  (1 | PlotID_unique),
                data = flux)

summary(mod_ch4)
anova(mod_ch4)

#Post hoc
emmeans(mod_ch4, pairwise ~ ThawStage)

# Check model assumptions
plot(mod_ch4)
qqnorm(resid(mod_ch4))
qqline(resid(mod_ch4))
